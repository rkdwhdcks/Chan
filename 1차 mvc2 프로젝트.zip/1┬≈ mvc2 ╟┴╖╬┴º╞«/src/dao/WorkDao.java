package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class WorkDao {

	private static WorkDao instance;

	private WorkDao() {

	}

	public static WorkDao getInstance() {
		if (instance == null) {
			instance = new WorkDao();
		}
		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public Work select1(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=200";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getDate(3));
				work.setWork2(rs.getDate(4));
				work.setWork3(rs.getDate(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

	public Work select2(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=300";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getDate(3));
				work.setWork2(rs.getDate(4));
				work.setWork3(rs.getDate(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

	public Work select3(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=400";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getDate(3));
				work.setWork2(rs.getDate(4));
				work.setWork3(rs.getDate(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

public Work productionSelect(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=300";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getTimestamp(3));
				work.setWork2(rs.getTimestamp(4));
				work.setWork3(rs.getTimestamp(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));
				work.setWork_count(rs.getInt(9));
				work.setWork_realcount(rs.getInt(10));
				work.setDefect_item(rs.getInt(11));
				System.out.println(work.getWork_count());

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

public Work productionStatus1(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update work set work1 = sysdate, work_name1 = ? , work_status = 1 "
				+ "where order_num = ?  and dept_num = 300";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work2;
	}

public Work productionStatus2(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update work set work2 = sysdate, work_name2 =? , work_status = 2 where order_num =? and dept_num = 300";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work2;
	}


	public Work productionStatus3(int order_num, String emp_name) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update work set work3 = sysdate, work_name3 = ? , work_status = 3 "
				+ "where order_num = ? and dept_num = 300";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work2;
	}


public Work productionInsert(int order_num, int work_count, int work_realcount, int defect_item)
			throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into work(order_num,dept_num, work_count, work_realcount, defect_item) values( ?, 400, ?,?,? )";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);
			pstmt.setInt(2, work_count);
			pstmt.setInt(3, work_realcount);
			pstmt.setInt(4, defect_item);

			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work2;
	}


public Work productionDefect(int order_num, int work_count, double item_defectRate) throws SQLException {
		Work work = new Work();

		double ran = Math.random();
		//범위 설정 -1~1
		double random1 = (ran * 2) - 1;
		double defect_item = work_count * (item_defectRate + random1) / 100;
		int work_realcount = (int) (work_count - defect_item);
		
		String sql = "update work set WORK_REALCOUNT = " + work_realcount + " , defect_item = " + defect_item
				+ " where dept_num = 300 and order_num = " + order_num;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work;
	}

public Work deliverselect3(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=400";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getTimestamp(3));
				work.setWork2(rs.getTimestamp(4));
				work.setWork3(rs.getTimestamp(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));
				work.setWork_count(rs.getInt(9));
				work.setWork_realcount(rs.getInt(10));
				work.setDefect_item(rs.getInt(11));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

public Work deliverstatus2(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work2 = sysdate , work_name2=?,work_status = 2"
				+ " where order_num= ? and dept_num=400";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();

		}
		return work2;
	}

	public Work deliverstatus3(int order_num, String emp_name) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work3 = sysdate , work_name3= ?, work_status = 3 "
				+ " where order_num= ? and dept_num=400";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();

		}
		return work2;
	}

	public Work deliverstatus1(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work1 = sysdate , work_name1= ? ,work_status = 1"
				+ " where order_num= ? and dept_num=400";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.setInt(2, order_num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();

		}

		return work2;
	}
public Work delivertotal(int item_code) throws SQLException {
		Work work = new Work();
		
		String sql = "select * from work , item where item_code=? and dept_num=400 and work3 is not null ";
		String sql1 = "update item set item_defectRate=? where item_code=? ";

		Connection conn = null;
		PreparedStatement pstmt = null;
		double tot = 0;
		double bad = 0;
		double result = 0;

		ResultSet rs = null;

		try {
		
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,item_code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
			
				work.setWork_count(rs.getInt("work_count"));
				work.setDefect_item(rs.getInt("defect_item"));

				tot += work.getWork_count();
			
				bad += work.getDefect_item();
				

				
			}
			result = (bad / tot) * 100;
		
			pstmt.close();

			pstmt = conn.prepareStatement(sql1);
			pstmt.setDouble(1,result);
			pstmt.setInt(2,item_code);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
			if (rs != null)
				rs.close();

		}

		return work;
	}

public int work_getTotalCnt() throws SQLException {
		int cnt = 1;
		String sql = "SELECT count(*)  FROM ( " + "                 SELECT rownum r, w.* from ("
				+ "SELECT * FROM WORK WHERE (ORDER_NUM , DEPT_NUM) NOT IN ( "
				+ "SELECT ORDER_NUM, DEPT_NUM  FROM  work  WHERE  dept_num = 400 AND work_status = 3 ) "
				+ "AND   (ORDER_NUM , DEPT_NUM) IN (  SELECT ORDER_NUM, MAX(DEPT_NUM)  FROM  work GROUP BY ORDER_NUM )"
				+ ") w )";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}

	public List<Work> work_listCount(int startRow, int endRow) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT *   " + "FROM (                   " + "        SELECT rownum r, w.*  "
				+ "        FROM      ( SELECT *  " + "                    FROM ( "
				+ "              SELECT  order_num, MAX(dept_num)dept_num, MAX(work1) work1, MAX(work2) work2, MAX(work3) work3, MAX(work_name1) work_name1, MAX(work_name2) work_name2, MAX(work_name3) work_name3 "
				+ "              FROM ( "
				+ "                    SELECT   order_num, dept_num,NVL(work3, NVL(work2, work1)) work1 , null work2 , null work3, NVL(work_name3, NVL(work_name2, work_name1)) work_name1 , null work_name2 , null work_name3 "
				+ "                    FROM   (SELECT  * FROM  work where dept_num = 200)   "
				+ "                    UNION  "
				+ "	      		    SELECT   order_num, dept_num, null work1 ,NVL(work3, NVL(work2, work1)) work2 , null work3 , null work_name1 , NVL(work_name3, NVL(work_name2, work_name1)) work_name2 , null work_name3  "
				+ "	      		    FROM  (SELECT  * FROM  work where dept_num = 300)  "
				+ "                    UNION "
				+ "	      		    SELECT    order_num, dept_num,null work1 , null work2 , NVL(work3, NVL(work2, work1)) work3 , null work_name1 ,  null work_name2 , NVL(work_name3, NVL(work_name2, work_name1)) work_name3 "
				+ "	      		    FROM (SELECT  * FROM  work where dept_num = 400)  " + "                   ) "
				+ "               GROUP BY order_num  " + "             ) w  "
				+ "                    WHERE (ORDER_NUM , DEPT_NUM) NOT IN ( SELECT ORDER_NUM, DEPT_NUM  FROM  work  WHERE  dept_num = 400 AND work_status = 3 ) "
				+ "                    AND   (ORDER_NUM , DEPT_NUM) IN (  SELECT ORDER_NUM, MAX(DEPT_NUM)  FROM  work GROUP BY ORDER_NUM ) "
				+ "                    ) w  " + "     )  " + "where r BETWEEN ? AND ?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;


		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Work work = new Work();

				work.setOrder_num(rs.getInt("order_num"));
				work.setDept_num(rs.getInt("dept_num"));
				work.setWork1(rs.getDate("work1"));
				work.setWork2(rs.getDate("work2"));
				work.setWork3(rs.getDate("work3"));
				work.setWork_name1(rs.getString("work_name1"));
				work.setWork_name2(rs.getString("work_name2"));
				work.setWork_name3(rs.getString("work_name3"));

				list.add(work);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}

		return list;
	}


	public int end_getTotalCnt() throws SQLException {
		int cnt = 1;
		String sql = "SELECT count(*) FROM WORK WHERE  (ORDER_NUM , DEPT_NUM) IN ("
				+ "        SELECT ORDER_NUM, DEPT_NUM " + "        FROM  work " + "        WHERE dept_num = 400 "
				+ "        AND work_status = 3" + "        )";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}

	public List<Work> end_listCount(int startRow, int endRow) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT *  FROM ( " + "                 SELECT rownum r, w.* from ("
				+ "					SELECT  order_num, MAX(dept_num)dept_num, MAX(work1) work1, MAX(work2) work2, MAX(work3) work3, MAX(work_name1) work_name1, MAX(work_name2) work_name2, MAX(work_name3) work_name3 "
				+ "                   	FROM (SELECT   order_num, dept_num,NVL(work3, NVL(work2, work1)) work1 , null work2 , null work3, NVL(work_name3, NVL(work_name2, work_name1)) work_name1 , null work_name2 , null work_name3 "
				+ "                       	FROM   (SELECT  * FROM  work where dept_num = 200)  UNION "
				+ "                           	SELECT   order_num, dept_num, null work1 ,NVL(work3, NVL(work2, work1)) work2 , null work3 , null work_name1 , NVL(work_name3, NVL(work_name2, work_name1)) work_name2 , null work_name3 "
				+ "                               	FROM  (SELECT  * FROM  work where dept_num = 300) UNION "
				+ "                                   	SELECT    order_num, dept_num,null work1 , null work2 , NVL(work3, NVL(work2, work1)) work3 , null work_name1 ,  null work_name2 , NVL(work_name3, NVL(work_name2, work_name1)) work_name3 "
				+ "                                       	FROM (SELECT  * FROM  work where dept_num = 400 and work3 is not null) ) "
				+ "                                           	GROUP BY order_num ) w ) where r BETWEEN ? AND ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Work work = new Work();

				work.setOrder_num(rs.getInt("order_num"));
				work.setDept_num(rs.getInt("dept_num"));
				work.setWork1(rs.getDate("work1"));
				work.setWork2(rs.getDate("work2"));
				work.setWork3(rs.getDate("work3"));
				work.setWork_name1(rs.getString("work_name1"));
				work.setWork_name2(rs.getString("work_name2"));
				work.setWork_name3(rs.getString("work_name3"));

				list.add(work);
				System.out.println("order_num->" + work.getOrder_num());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}

		return list;
	}

public Work ordSelect3(int order_num) throws SQLException {
		Work work = new Work();
		String sql = "select * from work where order_num=? and dept_num=200";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				work.setOrder_num(rs.getInt(1));
				work.setDept_num(rs.getInt(2));
				work.setWork1(rs.getDate(3));
				work.setWork2(rs.getDate(4));
				work.setWork3(rs.getDate(5));
				work.setWork_name1(rs.getString(6));
				work.setWork_name2(rs.getString(7));
				work.setWork_name3(rs.getString(8));
				work.setWork_count(rs.getInt(9));

			}
		} catch (Exception e) {
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return work;
	}

	public Work ordStatus(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work1=sysdate , work_name1=?, work_status = 1 where dept_num=200 and order_num ="
				+ order_num;
		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.executeUpdate();
		} catch (Exception e) {
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
		}
		return work2;
	}

	public Work ordStatus2(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work2=sysdate, work_name2=?, work_status = 2 where dept_num=200 and order_num ="
				+ order_num;
		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.executeUpdate();

		} catch (Exception e) {
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
		}
		return work2;
	}

	public Work ordStatus3(int order_num, String emp_name) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update work set work3=sysdate, work_name3=? , work_status = 3 where dept_num=200 and order_num ="
				+ order_num;
		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp_name);
			pstmt.executeUpdate();

		} catch (Exception e) {
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
		}
		return work2;
	}

	public Work ordInsert(int order_num, int work_count) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into work(order_num,dept_num,work_count) values(" + order_num + ", 300, " + work_count
				+ " )";

		Work work2 = new Work();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return work2;
	}
}