package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class PartDao {

	private static PartDao instance;

	private PartDao() {

	}

	public static PartDao getInstance() {
		if (instance == null) {
			instance = new PartDao();
		}
		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public int getTotalCnt() throws SQLException {
		int cnt = 1;
		String sql = "select count(*) from part";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}

	public List<Part> list(int startRow, int endRow) throws SQLException {
		List<Part> list = new ArrayList<Part>();
		String sql = "select * from (select rownum r, p.* from part p ) where r BETWEEN ? AND ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Part part = new Part();

				part.setP_code(rs.getInt(2));
				part.setP_name(rs.getString(3));
				part.setP_cost(rs.getInt(4));
				part.setP_count(rs.getInt(5));

				list.add(part);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}

		return list;
	}
	
	public Part select(int p_code) throws SQLException {
		Part part = new Part();
		String sql = "select * from part where p_code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_code);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				part.setP_code(rs.getInt(1));
				part.setP_name(rs.getString(2));
				part.setP_cost(rs.getInt(3));
				part.setP_count(rs.getInt(4));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return part;
	}

	public int insert(Part part) throws SQLException {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		String sql = "insert into part values(?,?,?,0)";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, part.getP_code());
			pstmt.setString(2, part.getP_name());
			pstmt.setInt(3, part.getP_cost());

			result = pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}
		return result;
	}

	public int update(Part part) throws SQLException {
		String sql = "update part set p_code=?,p_name=?,p_cost=? where p_code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, part.getP_code());
			pstmt.setString(2, part.getP_name());
			pstmt.setInt(3, part.getP_cost());
			pstmt.setInt(4, part.getP_code());

			result = pstmt.executeUpdate();
					
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}

		return result;
	}
	
	public List<Part> list() throws SQLException {
		List<Part> p_list = new ArrayList<Part>();
		
		Connection conn = null;
		Statement stmt = null;	ResultSet rs = null;
		
		String sql = "select * from part";
		
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				Part part = new Part();
				part.setP_code(rs.getInt("p_code"));
				part.setP_name(rs.getString("p_name"));
				part.setP_cost(rs.getInt("p_cost"));
				part.setP_count(rs.getInt("p_count"));
				p_list.add(part);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) rs.close();
			if (stmt != null) stmt.close();
			if (conn != null) conn.close();
		}
		
		return p_list;
	}

	public List<Part> ordPartList(int item_code) throws SQLException {
		List<Part> list = new ArrayList<Part>();
		String sql = "SELECT * FROM part WHERE p_code IN (SELECT p_code FROM recipe WHERE item_code= " + item_code
				+ " ) ORDER BY p_code";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Part part = new Part();
				part.setP_code(rs.getInt("p_code"));
				part.setP_name(rs.getString("p_name"));
				part.setP_count(rs.getInt("p_count"));
				list.add(part);
			}
		} catch (Exception e) {
		} finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
			if (rs != null)
				rs.close();
		}
		return list;
	}

	public int ordUpdate(int remain, int part_code) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "UPDATE part set p_count=? " + " WHERE p_code=? ";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, remain);
			pstmt.setInt(2, part_code);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result;
	}

	public Part ordSelect(int p_code) throws SQLException {
		Part part = new Part();
		String sql = "select * from part where p_code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_code);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				part.setP_code(rs.getInt(1));
				part.setP_name(rs.getString(2));
				part.setP_cost(rs.getInt(3));
				part.setP_count(rs.getInt(4));
			}
		} catch (Exception e) {
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return part;
	}

	public int ordUpdate(int p_code, int p_count, int totalParts) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "UPDATE part SET p_count=(?+?) WHERE p_code=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, totalParts);
			pstmt.setInt(2, p_count);
			pstmt.setInt(3, p_code);
			result = pstmt.executeUpdate();

		} catch (Exception e) {
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result;
	}
}
