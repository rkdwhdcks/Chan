package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ItemDao {

	private static ItemDao instance;

	private ItemDao() {

	}

	public static ItemDao getInstance() {
		if (instance == null) {
			instance = new ItemDao();
		}
		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public Item select(int item_code) throws SQLException {
		Item item = new Item();
		String sql = "select * from item where item_code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, item_code);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				item.setItem_code(rs.getInt(1));
				item.setItem_name(rs.getString(2));
				item.setItem_cost(rs.getInt(3));
				item.setItem_defectRate(rs.getDouble(4));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return item;
	}

	public Item deliverselect(int order_num) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from item i,orders o where o.order_num=?" + "and o.item_code = i.item_code";
		Item item = new Item();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);
			rs = pstmt.executeQuery();
			if (rs.next()) {

				item.setItem_code(rs.getInt("item_code"));
				item.setItem_cost(rs.getInt("item_cost"));
				item.setItem_name(rs.getString("item_name"));
				item.setItem_defectRate(rs.getDouble("item_defectRate"));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
			if (rs != null)
				rs.close();
		}

		return item;
	}

	public Item productionSelect(int order_num) throws SQLException {
		Item item = new Item();
		String sql = "select * from item i, orders o where o.order_num = ?" + " and o.item_code = i.item_code";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				item.setItem_code(rs.getInt(1));
				item.setItem_name(rs.getString(2));
				item.setItem_cost(rs.getInt(3));
				item.setItem_defectRate(rs.getDouble(4));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return item;
	}

	public int getTotalCnt() throws SQLException {
		Connection conn = null;
		String sql = "select count(*) from item";
		Statement stmt = null;
		ResultSet rs = null;
		int cnt = 0;

		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}

		return cnt;
	}

	public List<Item> listCount(int startRow, int endRow) throws SQLException {
		List<Item> list = new ArrayList<>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from (select rownum rn, i.* from item i)" + "where rn between ? and ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Item item = new Item();
				item.setItem_code(rs.getInt("item_code"));
				item.setItem_cost(rs.getInt("item_cost"));
				item.setItem_name(rs.getString("item_name"));
				item.setItem_defectRate(rs.getDouble("item_defectrate"));
				list.add(item);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return list;
	}

	public int insert_item(Item item) throws SQLException {
		int result1 = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into item values(?,?,?,5)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, item.getItem_code());
			pstmt.setString(2, item.getItem_name());
			pstmt.setInt(3, item.getItem_cost());

			result1 = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result1;
	}

	public Item ordSelect(int item_code) throws SQLException {
		Item item = new Item();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from item where item_code=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, item_code);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				item.setItem_code(rs.getInt("item_code"));
				item.setItem_cost(rs.getInt("item_cost"));
				item.setItem_name(rs.getString("item_name"));
			}
		} catch (Exception e) {
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return item;
	}
}
