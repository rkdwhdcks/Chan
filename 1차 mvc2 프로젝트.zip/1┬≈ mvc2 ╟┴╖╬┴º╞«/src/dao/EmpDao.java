package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class EmpDao {
	private static EmpDao instance;

	private EmpDao() {
	}

	public static EmpDao getInstance() {
		if (instance == null) {
			instance = new EmpDao();
		}
		return instance;
	}

	private static Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public int insert(Emp emp) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into emp values(?,?,?,?,?,?,?,to_char(?,'YYYY-MM-DD'),null)";
		int result = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, emp.getEmp_num());
			pstmt.setString(2, emp.getEmp_name());
			pstmt.setInt(3, emp.getDept_num());
			pstmt.setString(4, emp.getEmp_rank());
			pstmt.setString(5, emp.getEmp_tel());
			pstmt.setString(6, emp.getEmp_address());
			pstmt.setString(7, emp.getEmp_pw());
			pstmt.setDate(8, emp.getEmp_joinDate());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
		if (pstmt != null)
			pstmt.close();
		if (conn != null)
			conn.close();
		return result;
	}

	public int getTotalCnt(String emp_selected) throws SQLException {
		int tot = 0;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from (" + emp_selected + ")";
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				tot = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		return tot;
	}

	public List<Emp> list(int startRow, int endRow) throws SQLException {

		List<Emp> list = new ArrayList<Emp>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from(select rownum rn, ee.* from (select * from emp ORDER BY emp_num)ee) where rn between ? and ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Emp emp = new Emp();
				emp.setEmp_num(rs.getInt("emp_num"));
				emp.setEmp_name(rs.getString("emp_name"));
				emp.setDept_num(rs.getInt("dept_num"));
				emp.setEmp_rank(rs.getString("emp_rank"));
				emp.setEmp_tel(rs.getString("emp_tel"));
				emp.setEmp_address(rs.getString("emp_address"));
				emp.setEmp_pw(rs.getString("emp_pw"));
				emp.setEmp_joinDate(rs.getDate("emp_joinDate"));
				list.add(emp);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return list;
	}

	public int emp_check(Emp emp) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from emp where emp_num=?";
		int result = 0;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, emp.getEmp_num());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				if (emp.getEmp_pw().equals(rs.getString(7))) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();

		}
		return result;
	}

	public Emp select(int emp_num) throws SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from emp,DEPT where emp.dept_num=dept.dept_num and emp_num=" + emp_num;
		Emp emp = new Emp();
		Dept dept = new Dept();
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				emp.setEmp_num(rs.getInt("emp_num"));
				emp.setEmp_name(rs.getString("emp_name"));
				emp.setDept_num(rs.getInt("dept_num"));
				emp.setEmp_rank(rs.getString("emp_rank"));
				emp.setEmp_tel(rs.getString("emp_tel"));
				emp.setEmp_address(rs.getString("emp_address"));
				emp.setEmp_pw(rs.getString("emp_pw"));
				emp.setEmp_joinDate(rs.getDate("emp_joinDate"));
				emp.setEmp_retireDate(rs.getDate("emp_retireDate"));
				dept.setDept_name(rs.getString("dept_name"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		return emp;
	}

	public int update(Emp emp) throws SQLException {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		System.out.println("emp.getEmp_num -> " + emp.getEmp_num());
		String sql = "update emp set dept_num=?,emp_rank=?,emp_tel=?,emp_address=?,emp_pw=?,emp_retireDate=to_char(?,'yyyy-mm-dd') where emp_num="
				+ emp.getEmp_num();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, emp.getDept_num());
			pstmt.setString(2, emp.getEmp_rank());
			pstmt.setString(3, emp.getEmp_tel());
			pstmt.setString(4, emp.getEmp_address());
			pstmt.setString(5, emp.getEmp_pw());
			pstmt.setDate(6, emp.getEmp_retireDate());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result;
	}

	public int delete(int emp_num, String emp_pw) throws SQLException {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from emp where emp_num=? and emp_pw=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, emp_num);
			pstmt.setString(2, emp_pw);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result;
	}

	public List<Emp> listCheck(int startRow, int endRow, String emp_kindSelect, String totdept_num)
			throws SQLException {
		List<Emp> list = new ArrayList<Emp>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from(select rownum rn, ee.* from (select * from emp where dept_num in (" + totdept_num
				+ ") and " + emp_kindSelect + " ORDER BY emp_num)ee) where rn between " + startRow + " and " + endRow;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Emp emp = new Emp();
				emp.setEmp_num(rs.getInt("emp_num"));
				emp.setEmp_name(rs.getString("emp_name"));
				emp.setDept_num(rs.getInt("dept_num"));
				emp.setEmp_rank(rs.getString("emp_rank"));
				emp.setEmp_tel(rs.getString("emp_tel"));
				emp.setEmp_address(rs.getString("emp_address"));
				emp.setEmp_pw(rs.getString("emp_pw"));
				emp.setEmp_joinDate(rs.getDate("emp_joinDate"));
				emp.setEmp_retireDate(rs.getDate("emp_retireDate"));
				list.add(emp);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		return list;
	}

	public Emp boardselect(int emp_num) throws SQLException {

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from emp,DEPT where emp.dept_num=dept.dept_num and emp_num=" + emp_num;

		Emp emp = new Emp();
		Dept dept = new Dept();
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				emp.setEmp_num(rs.getInt("emp_num"));
				emp.setEmp_name(rs.getString("emp_name"));
				emp.setDept_num(rs.getInt("dept_num"));
				emp.setEmp_rank(rs.getString("emp_rank"));
				emp.setEmp_tel(rs.getString("emp_tel"));
				emp.setEmp_address(rs.getString("emp_address"));
				emp.setEmp_pw(rs.getString("emp_pw"));
				emp.setEmp_joinDate(rs.getDate("emp_joinDate"));
				System.out.println(rs.getDate("emp_joinDate"));
				dept.setDept_name(rs.getString("dept_name"));
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		return emp;
	}
}
