package dao;

public class Item {

	private int item_code;
	private String item_name;
	private int item_cost;
	private double item_defectRate;

	public int getItem_code() {
		return item_code;
	}

	public void setItem_code(int item_code) {
		this.item_code = item_code;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public int getItem_cost() {
		return item_cost;
	}

	public void setItem_cost(int item_cost) {
		this.item_cost = item_cost;
	}

	public double getItem_defectRate() {
		return item_defectRate;
	}

	public void setItem_defectRate(double item_defectRate) {
		this.item_defectRate = item_defectRate;
	}

}
