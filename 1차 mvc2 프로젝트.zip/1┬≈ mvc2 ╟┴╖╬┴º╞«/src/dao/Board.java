package dao;

import java.util.Date;

public class Board {
   private int board_num;
   private String board_title;
   private String board_content;
   private String board_file;
   private Date board_date;
   private int emp_num;
   // ��ȸ��
   private String emp_name;
   
   public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
public int getBoard_num() {
      return board_num;
   }
   public void setBoard_num(int board_num) {
      this.board_num = board_num;
   }
   public String getBoard_title() {
      return board_title;
   }
   public void setBoard_title(String board_title) {
      this.board_title = board_title;
   }
   public String getBoard_content() {
      return board_content;
   }
   public void setBoard_content(String board_content) {
      this.board_content = board_content;
   }
   public String getBoard_file() {
      return board_file;
   }
   public void setBoard_file(String board_file) {
      this.board_file = board_file;
   }
   public Date getBoard_date() {
      return board_date;
   }
   public void setBoard_date(Date board_date) {
      this.board_date = board_date;
   }
   public int getEmp_num() {
      return emp_num;
   }
   public void setEmp_num(int emp_num) {
      this.emp_num = emp_num;
   }
}