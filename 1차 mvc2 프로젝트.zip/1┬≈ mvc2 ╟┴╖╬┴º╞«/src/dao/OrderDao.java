package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class OrderDao {

	private static OrderDao instance;

	private OrderDao() {

	}

	public static OrderDao getInstance() {
		if (instance == null) {
			instance = new OrderDao();
		}
		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public int getTotalCnt() throws SQLException {
		int cnt = 1;
		String sql = "select count(*) from orders";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}

public List<Order> list(int startRow, int endRow) throws SQLException {
		List<Order> list = new ArrayList<Order>();
		String sql = "select * from (select rownum r, o.* from (select * from orders order by order_num desc) o ) where r BETWEEN ? AND ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Order order = new Order();

				order.setOrder_num(rs.getInt(2));
				order.setOrder_company(rs.getString(3));
				order.setItem_count(rs.getInt(4));
				order.setOrder_date(rs.getDate(5));
				order.setItem_code(rs.getInt(6));
				order.setDept_num(rs.getInt(7));
				order.setOrder_duedate(rs.getDate(8));

				list.add(order);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}
		return list;
	}

public Order select(int order_num) throws SQLException {
		Order order = new Order();
		String sql = "select order_num,order_company,item_count,order_date,item_code,dept_num,order_duedate, trunc(order_duedate - sysdate) remain_date from orders where order_num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				order.setOrder_num(rs.getInt(1));
				order.setOrder_company(rs.getString(2));
				order.setItem_count(rs.getInt(3));
				order.setItem_code(rs.getInt(5));
				order.setDept_num(rs.getInt(6));
				order.setOrder_duedate(rs.getDate(7));
				order.setOrder_remaindate(rs.getInt(8));

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return order;
	}

	public int update(Order order) throws SQLException {
		String sql = "update orders set item_code=?,order_company=?,item_count=?,dept_num=? where order_num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, order.getItem_code());
			pstmt.setString(2, order.getOrder_company());
			pstmt.setInt(3, order.getItem_count());
			pstmt.setInt(4, order.getDept_num());
			pstmt.setInt(5, order.getOrder_num());

			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
		}
		return result;
	}

public int insert(Order order, Item item) throws SQLException {
		int result = 0;
		int num = 0;
		int work_count = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql1 = "select nvl(max(order_num), 0) from orders";
		String sql = "insert into orders values(?,?,?,sysdate,?,200,sysdate+7)";
		String sql2 = "insert into work(order_num, dept_num,work_count) values(?,200,?)";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement(sql1);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				num = rs.getInt(1) + 1;

				rs.close();
				pstmt.close();
			}

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, order.getOrder_company());
			pstmt.setInt(3, order.getItem_count());
			pstmt.setInt(4, order.getItem_code());
			result = pstmt.executeUpdate();
			
			pstmt.close();
			if (result > 0) {
				work_count = (int) ((order.getItem_count()*(item.getItem_defectRate()+2)/100)+order.getItem_count());
				
				pstmt = conn.prepareStatement(sql2);
				pstmt.setInt(1, num);
				pstmt.setInt(2, work_count);

				result = pstmt.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return result;
	}

public int getProductionCnt() throws SQLException {
		int cnt = 1;
		String sql = "select count(*) from  work  where dept_num = 300 and work_name3 is null";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}


public List<Order> productionlist(int startRow, int endRow) throws SQLException {
	List<Order> list = new ArrayList<Order>();
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "select * from  " + "               (select rownum r,od.* from  "
			+ "               (select  o.order_num, o.order_company, o.order_date, o.item_code, o.item_count, o.order_duedate, w.dept_num "
			+ "               from  work w, orders o " + "                where w.order_num = o.order_num "
			+ "               and  w.dept_num = 300 and w.work_name3 is null  "
			+ "               order by o.order_num) od " + "               ) where r BETWEEN ? AND ? ";

	try {
		conn = getConnection();
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, startRow);
		pstmt.setInt(2, endRow);

		rs = pstmt.executeQuery();

		while (rs.next()) {
			Order order = new Order();

			order.setOrder_num(rs.getInt("order_num"));
			order.setOrder_company(rs.getString("order_company"));
			order.setOrder_date(rs.getDate("order_date"));
			order.setItem_code(rs.getInt("item_code"));
			order.setDept_num(rs.getInt("dept_num"));
			order.setItem_count(rs.getInt("item_count"));
			
			order.setOrder_duedate(rs.getDate("order_duedate"));
			
			
			list.add(order);
			
			
		}
	} catch (Exception e) {
		System.out.println(e.getMessage());
	} finally {
		if (rs != null) {
			rs.close();
		}
		if (conn != null) {
			conn.close();
		}
		if (pstmt != null) {
			pstmt.close();
		}
	}

	return list;
}

public Order productionSelect(int order_num) throws SQLException {
	Order order = new Order();
	String sql = "select * from orders where order_num=?";
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	try {
		conn = getConnection();
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, order_num);

		rs = pstmt.executeQuery();

		if (rs.next()) {
			order.setOrder_num(rs.getInt(1));
			order.setOrder_company(rs.getString(2));
			order.setItem_count(rs.getInt(3));
			order.setOrder_date(rs.getDate(4));
			order.setItem_code(rs.getInt(5));
			order.setDept_num(rs.getInt(6));
			order.setOrder_duedate(rs.getDate(7));

		}
	} catch (Exception e) {
		System.out.println(e.getMessage());
	} finally {
		if (conn != null) {
			conn.close();
		}
		if (pstmt != null) {
			pstmt.close();
		}
		if (rs != null) {
			rs.close();
		}
	}
	return order;
}

public Order deliverselect(int order_num) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select *from orders where order_num= ?";

		Order order = new Order();

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				order.setOrder_num(rs.getInt("order_num"));
				order.setItem_code(rs.getInt("item_code"));
				order.setOrder_company(rs.getString("order_company"));
				order.setItem_count(rs.getInt("item_count"));
				order.setOrder_date(rs.getDate("order_date"));
				order.setOrder_duedate(rs.getDate("order_duedate"));

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		finally {
			if (conn != null)
				conn.close();
			if (pstmt != null)
				pstmt.close();
			if (rs != null)
				rs.close();
		}
		return order;
	}

public int getDeliverTotalCnt() throws SQLException {
		int cnt = 1;
		String sql = "select count(*) from work where dept_num=400 and work_name3 is null";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return cnt;
	}

public List<Order> deliverlist(int startRow, int endRow) throws SQLException {
		List<Order> list = new ArrayList<Order>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from  " + "               (select rownum r,od.* from  "
				+ "               (select  o.order_num, o.order_company, o.order_date, o.item_code, o.item_count,o.order_duedate, w.dept_num "
				+ "               from  work w, orders o  " + "                where w.order_num = o.order_num  "
				+ "               and  w.dept_num = 400 and w.work_name3 is null   "
				+ "               order by o.order_num) od" + "               ) where r BETWEEN ? AND ? ";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order.setOrder_num(rs.getInt("order_num"));
				order.setDept_num(rs.getInt("dept_num"));
				order.setItem_code(rs.getInt("item_code"));
				order.setOrder_company(rs.getString("order_company"));
				order.setOrder_date(rs.getDate("order_date"));
				order.setItem_count(rs.getInt("item_count"));
				order.setOrder_duedate(rs.getDate("order_duedate"));
				list.add(order);
	
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();

		}

		return list;

	}

public List<Order> order_list() throws SQLException {
		List<Order> list = new ArrayList<>();
		
		String sql = "select * from orders";
		
		Connection conn = null;
		Statement stmt = null;	ResultSet rs = null;
		
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				Order order = new Order();
				
				order.setOrder_num(rs.getInt("order_num"));
				order.setDept_num(rs.getInt("dept_num"));
				order.setItem_code(rs.getInt("item_code"));
				order.setItem_count(rs.getInt("item_count"));
				order.setOrder_company(rs.getString("order_company"));
				order.setOrder_date(rs.getDate("order_date"));
				order.setOrder_duedate(rs.getDate("order_duedate"));
				
				list.add(order);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) rs.close();
			if (stmt != null) stmt.close();
			if (conn != null) conn.close();
		}
		
		return list;
	}

public Order ordSelect(int order_num) throws SQLException {
		Order orders = new Order();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from orders where order_num=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, order_num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				orders.setOrder_num(rs.getInt("order_num"));
				orders.setDept_num(rs.getInt("dept_num"));
				orders.setItem_code(rs.getInt("item_code"));
				orders.setItem_count(rs.getInt("item_count"));
				orders.setOrder_company(rs.getString("order_company"));
				orders.setOrder_date(rs.getDate("order_date"));
				orders.setOrder_duedate(rs.getDate("order_duedate"));
			}
		} catch (Exception e) {
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return orders;
	}

	public int getOrdTotalCnt() throws SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		int tot = 0;
		String sql = "select count(*) from work where dept_num=200 and work_name3 is null";
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next())
				tot = rs.getInt(1);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		return tot;
	}

	public List<Order> ordList(int startRow, int endRow) throws SQLException {
		List<Order> list = new ArrayList<Order>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from (" + "            select rownum r,od.* from "
				+ "            (select  o.order_num, o.order_company, o.order_date, o.item_code, o.item_count,o.order_duedate,  w.dept_num "
				+ "            from  work w, orders o " + "            where w.order_num = o.order_num "
				+ "            and  w.dept_num = 200 and w.work_name3 is null "
				+ "            order by o.order_num) od " + "            ) where r BETWEEN ? AND ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Order orders = new Order();
				orders.setOrder_num(rs.getInt("order_num"));
				orders.setOrder_company(rs.getString("order_company"));
				orders.setItem_code(rs.getInt("item_code"));
				orders.setItem_count(rs.getInt("item_count"));
				orders.setDept_num(rs.getInt("dept_num"));
				orders.setOrder_date(rs.getDate("order_date"));
				orders.setOrder_duedate(rs.getDate("order_duedate"));
				
				list.add(orders);

			}
		} catch (Exception e) {
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return list;
	}
}
