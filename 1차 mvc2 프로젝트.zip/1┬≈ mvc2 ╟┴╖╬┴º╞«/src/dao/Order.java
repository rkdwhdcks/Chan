package dao;

import java.util.Date;

public class Order {
	private int order_num;
	private String order_company;
	private int item_count;
	private Date order_date;
	private int item_code;
	private int dept_num;
	private Date order_duedate;
	private int order_remaindate;

	public int getOrder_remaindate() {
		return order_remaindate;
	}

	public void setOrder_remaindate(int order_remaindate) {
		this.order_remaindate = order_remaindate;
	}

	public Date getOrder_duedate() {
		return order_duedate;
	}

	public void setOrder_duedate(Date order_duedate) {
		this.order_duedate = order_duedate;
	}

	public int getOrder_num() {
		return order_num;
	}

	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}

	public String getOrder_company() {
		return order_company;
	}

	public void setOrder_company(String order_company) {
		this.order_company = order_company;
	}

	public int getItem_count() {
		return item_count;
	}

	public void setItem_count(int item_count) {
		this.item_count = item_count;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public int getItem_code() {
		return item_code;
	}

	public void setItem_code(int item_code) {
		this.item_code = item_code;
	}

	public int getDept_num() {
		return dept_num;
	}

	public void setDept_num(int dept_num) {
		this.dept_num = dept_num;
	}

}
