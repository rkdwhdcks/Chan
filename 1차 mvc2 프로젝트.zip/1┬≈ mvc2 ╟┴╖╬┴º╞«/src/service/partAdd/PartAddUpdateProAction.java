package service.partAdd;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class PartAddUpdateProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");
			String p_code_ = request.getParameter("p_code");
			int p_code = Integer.parseInt(p_code_);
			String p_name = request.getParameter("p_name");
			int p_cost = Integer.parseInt(request.getParameter("p_cost"));
//			int p_count = Integer.parseInt(request.getParameter("p_count"));
			
			Part part = new Part();

			part.setP_code(p_code);
			part.setP_name(p_name);
			part.setP_cost(p_cost);
//			part.setP_count(p_count);

			PartDao pd = PartDao.getInstance();

			int result = pd.update(part);

			request.setAttribute("result", result);
			request.setAttribute("p_code", part.getP_code());
			request.setAttribute("pageNum", pageNum);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "partAdd/partAddUpdatePro.jsp";
	}

}
