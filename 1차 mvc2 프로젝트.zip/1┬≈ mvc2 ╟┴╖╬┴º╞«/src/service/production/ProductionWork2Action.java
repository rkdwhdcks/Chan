package service.production;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class ProductionWork2Action implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			
			String work_name2 = request.getParameter("work_name2");
			
			String work_name3 = request.getParameter("work_name3");
			
			String work_name1 = request.getParameter("work_name1");
			
			String emp_name = (String) session.getAttribute("emp_name");
			
			double item_defectRate = Double.parseDouble(request.getParameter("item_defectRate"));
			
			int work_count = Integer.parseInt(request.getParameter("work_count"));
			
			
			
			
			
			OrderDao od = OrderDao.getInstance();
			
			Order orders = od.productionSelect(order_num);
			
			ItemDao id = ItemDao.getInstance();
			Item item = id.productionSelect(order_num);
			WorkDao wd = WorkDao.getInstance();
			
			
			Work work = wd.productionSelect(order_num);
			
			
			request.setAttribute("order_num", order_num);
			request.setAttribute("orders", orders);
			request.setAttribute("item", item);
			request.setAttribute("work", work);
			
			
			
			if(work_name2.equals("")&&!work_name1.equals("")) {
			
			
			Work work1 = wd.productionDefect(order_num,work_count,item_defectRate);
			
			
			request.setAttribute("work1", work1);
			
//			Work work2 = wd.productionStatus2(order_num);
			Work work2 = wd.productionStatus2(order_num,emp_name);
			
			request.setAttribute("work2", work2);
			
			Work work3 = wd.productionSelect(order_num);
			request.setAttribute("work3", work3);
			
			
			}else return  "productionFalse.do?order_num=${orders.order_num}";
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return "productionOkpro.do?order_num=${orders.order_num}";
	}

}
