package service.production;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class ProductionWork3Action implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			String work_name2 = request.getParameter("work_name2");
			String work_name3 = request.getParameter("work_name3");
			int work_count = Integer.parseInt(request.getParameter("work_count"));
			int work_realcount = Integer.parseInt(request.getParameter("work_realcount"));
			int defect_item = Integer.parseInt(request.getParameter("defect_item"));
			String emp_name = (String) session.getAttribute("emp_name");
			
			
			OrderDao od = OrderDao.getInstance();
			Order orders = od.productionSelect(order_num);
			ItemDao id = ItemDao.getInstance();
			Item item = id.productionSelect(order_num);
			WorkDao wd = WorkDao.getInstance();
			Work work = wd.productionSelect(order_num);
			
			
			request.setAttribute("order_num", order_num);
			request.setAttribute("orders", orders);
			request.setAttribute("item", item);
			request.setAttribute("work", work);
			
			
			if(work_name3.equals("")&&!work_name2.equals("")) {
			
			Work work2 = wd.productionStatus3(order_num,emp_name);
			Work insert = wd.productionInsert(order_num,work_count,work_realcount,defect_item);
			
			request.setAttribute("work2", work2);
			
			Work work3 = wd.productionSelect(order_num);
			request.setAttribute("work3", work3);
			request.setAttribute("insert", insert);
			
			}else return  "productionFalse.do?order_num=${orders.order_num}";
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return "productionOkpro2.do";
	}

}
