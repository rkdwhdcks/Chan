package service.board;


import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.Board;
import dao.BoardDao;
import service.CommandProcess;

public class BoardWriteProAction implements CommandProcess {

	
	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String savePath = request.getServletContext().getRealPath("uploadFile");
		int sizeLimit = 1024*1024*15;
		
		
		try {

			MultipartRequest multi = new MultipartRequest(request, savePath, sizeLimit, "utf-8",
					new DefaultFileRenamePolicy());
			Enumeration files = multi.getFileNames();
			String file = (String) files.nextElement();
			String filename = multi.getFilesystemName(file);
			String fullpath = "uploadFile\\" + filename;
			request.setCharacterEncoding("utf-8");
					
	        String pageNum = multi.getParameter("pageNum");
			
			
			Board board = new Board();
			board.setBoard_num(Integer.parseInt(multi.getParameter("board_num")));
			board.setEmp_num(Integer.parseInt(multi.getParameter("emp_num")));
			board.setBoard_title(multi.getParameter("board_title"));
			board.setBoard_content(multi.getParameter("board_content"));
			board.setBoard_file(fullpath);
			
			BoardDao bd = BoardDao.getInstance();
			int result = bd.boardinsert(board);
			
			
			
			
			request.setAttribute("board_num", board.getBoard_num());
			request.setAttribute("result", result);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("fullpath", fullpath);
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return "board/boardWritePro.jsp";
	}

	

}
