package service.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Board;
import dao.BoardDao;
import service.CommandProcess;

public class BoardDeleteFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int board_num = Integer.parseInt(request.getParameter("board_num"));
			String pageNum = request.getParameter("pageNum");
			BoardDao bd = BoardDao.getInstance();
			Board board = bd.boardselect(board_num);
			request.setAttribute("board_num", board_num);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("board", board);
		} catch(Exception e)  { System.out.println(e.getMessage());	}
		return "board/boardDeleteForm.jsp";
	}

}
