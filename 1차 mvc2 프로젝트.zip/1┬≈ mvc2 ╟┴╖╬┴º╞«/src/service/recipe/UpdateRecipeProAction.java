package service.recipe;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Recipe;
import dao.RecipeDao;
import service.CommandProcess;

public class UpdateRecipeProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("utf-8");
			
			RecipeDao rd = RecipeDao.getInstance();
			Recipe recipe = new Recipe();
			
			int result = 0;
			String[] need_count = request.getParameterValues("part_num");
			String[] p_code = request.getParameterValues("p_code");

			recipe.setItem_code(Integer.parseInt(request.getParameter("item_code")));
			
			for (int i = 0; i < need_count.length; i++) {
				recipe.setP_code(Integer.parseInt(p_code[i]));
				recipe.setNeed_count(Integer.parseInt(need_count[i]));

				result = rd.update(recipe);
			}
			
			request.setAttribute("result", result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return "recipe/updateRecipePro.jsp";
	}

}
