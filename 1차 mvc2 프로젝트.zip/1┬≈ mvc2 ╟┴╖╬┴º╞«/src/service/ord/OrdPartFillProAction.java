package service.ord;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class OrdPartFillProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			int p_code = Integer.parseInt(request.getParameter("p_code"));
			int p_count = Integer.parseInt(request.getParameter("p_count"));
			System.out.println("OrdPartFillProAction  order_num ->" + order_num);
			System.out.println("OrdPartFillProAction  item_code ->" + item_code);
			PartDao pd = PartDao.getInstance();
			Part part = pd.ordSelect(p_code);
			int totalParts = part.getP_count();
			System.out.println("OrdPartFillProAction  totalParts ->" + totalParts);
			if (p_count < 0) {
				request.setAttribute("order_num", order_num);
				request.setAttribute("item_code", item_code);
				return "/ord/ordPartFillPro2.jsp";
			} 
			int result = pd.ordUpdate(p_code, p_count, totalParts);
			
			request.setAttribute("result", result);
			request.setAttribute("order_num", order_num);
			request.setAttribute("item_code", item_code);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "/ord/ordPartFillPro.jsp";
	}

}
