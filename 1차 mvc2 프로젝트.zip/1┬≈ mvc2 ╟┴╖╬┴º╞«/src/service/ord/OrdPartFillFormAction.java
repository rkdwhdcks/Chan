package service.ord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import service.CommandProcess;

public class OrdPartFillFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int order_num = Integer.parseInt(request.getParameter("order_num"));
		int item_code = Integer.parseInt(request.getParameter("item_code"));
		try {
			PartDao pd = PartDao.getInstance();
//			List<Part> partlist = pd.ordPartList();

			
			RecipeDao rd = RecipeDao.getInstance();
			List<Recipe> recipeList = rd.ordRecipeList(item_code);
			
			System.out.println("recipeList->"+recipeList);
			
			List<Integer> partNeeds = new ArrayList<>();
			for (int i = 0; i < recipeList.size(); i++) {
				partNeeds.add((Integer) recipeList.get(i).getNeed_count());
			}

			
			List<Part> partList = pd.ordPartList(item_code); 
			
			List<String> partNames = new ArrayList<>();
			List<Integer> partCounts = new ArrayList<>();
			for (int i = 0; i < partList.size(); i++) {
				partNames.add((String) partList.get(i).getP_name());
				partCounts.add((Integer) partList.get(i).getP_count());
			}
			
			
			request.setAttribute("partList", partList);
			request.setAttribute("order_num", order_num);
			request.setAttribute("item_code", item_code);
			request.setAttribute("partNames", partNames);
			request.setAttribute("partCounts", partCounts);
			request.setAttribute("partNeeds", partNeeds);
			} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "/ord/ordPartFillForm.jsp";
	}

}
