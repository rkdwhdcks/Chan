package service.ord;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class Ord2Action implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			String work_name1 = request.getParameter("work_name1");
			String work_name2 = request.getParameter("work_name2");
			String work_name3 = request.getParameter("work_name3");
			String emp_name = (String) session.getAttribute("emp_name");
			

			OrderDao od = OrderDao.getInstance();
			Order orders = od.ordSelect(order_num);
		
			ItemDao id = ItemDao.getInstance();
			Item item = id.ordSelect(item_code);
		
			WorkDao wd = WorkDao.getInstance();
			Work work= wd.ordSelect3(order_num);
		
			
		
			request.setAttribute("order_num", order_num);
			request.setAttribute("item_code", item_code);
			
			request.setAttribute("orders", orders);
		
			request.setAttribute("work", work);
		
			request.setAttribute("item", item);
			
			
			if(work_name2.equals("")&&!work_name1.equals("")) {
				
					Work work2= wd.ordStatus2(order_num, emp_name);
			
					request.setAttribute("work2", work2);
				
					Work work3= wd.ordSelect3(order_num);
			
					request.setAttribute("work3", work3);
				
					
			
				
			}else return "ordFalse.do";
	
		
			
		}catch (Exception e) {
		
		}

return "ordOkPro.do?order_num=${orders.order_num}";
}

}