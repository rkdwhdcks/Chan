package service.workStatus;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class WorkStatusContentAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			request.setCharacterEncoding("utf-8");
			String order_num_=request.getParameter("order_num");
			int order_num = Integer.parseInt(order_num_);
			
			OrderDao od = OrderDao.getInstance();
			Order order = od.select(order_num);

			int item_code = order.getItem_code();
			
			WorkDao wd = WorkDao.getInstance();
			Work work1 = wd.select1(order_num);
			Work work2 = wd.select2(order_num);
			Work work3 = wd.select3(order_num);
			
			ItemDao id = ItemDao.getInstance();
			Item item = id.select(item_code);
			
			request.setAttribute("order", order);
			request.setAttribute("work1", work1);
			request.setAttribute("work2", work2);
			request.setAttribute("work3", work3);
			request.setAttribute("item", item);
			
			System.out.println(order.getOrder_remaindate());
			
		} catch (Exception e) {

		}
		return "workStatus/workStatusContent.jsp";
	}

}
