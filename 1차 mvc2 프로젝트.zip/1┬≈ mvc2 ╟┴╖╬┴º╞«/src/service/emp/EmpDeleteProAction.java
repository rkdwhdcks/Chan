package service.emp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import service.CommandProcess;

public class EmpDeleteProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			try {
			int result = 0;
			int emp_num = Integer.parseInt(request.getParameter("emp_num"));
			int emp_num_re = Integer.parseInt(request.getParameter("emp_num_re"));
			String emp_pw = request.getParameter("emp_pw");
			
			if (emp_num == emp_num_re) {
			EmpDao ed = EmpDao.getInstance();
			result = ed.delete(emp_num, emp_pw);
			request.setAttribute("result", result);
			}
			
			} catch (Exception e) {
			System.out.println(e.getMessage());
			}
		return "emp/empDeletePro.jsp";
	}
}
