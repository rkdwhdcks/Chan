package service.emp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Dept;
import dao.DeptDao;
import dao.Emp;
import dao.EmpDao;
import service.CommandProcess;

public class EmpLoginProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Emp emp = new Emp();
			emp.setEmp_num(Integer.parseInt(request.getParameter("emp_num")));
			emp.setEmp_pw(request.getParameter("emp_pw"));
			EmpDao ed = EmpDao.getInstance();
			int result = ed.emp_check(emp);
			request.setAttribute("result", result);
			
			if (result == 1) {
				HttpSession session = request.getSession();
				int emp_num = Integer.parseInt(request.getParameter("emp_num"));
				emp = ed.select(emp_num);
				
				session.setAttribute("emp_name", emp.getEmp_name());
				session.setAttribute("dept_num", emp.getDept_num());
				session.setAttribute("emp_rank", emp.getEmp_rank());
				session.setAttribute("emp_num", emp.getEmp_num());
				
				int dept_num = emp.getDept_num();
				DeptDao dd = DeptDao.getInstance();
				Dept dept = dd.select(dept_num);
				
				session.setAttribute("dept_name", dept.getDept_name());
				
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "emp/empLoginPro.jsp";
	}
}
