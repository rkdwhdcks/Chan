package service.itemOrderConfirm;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Order;
import dao.OrderDao;
import service.CommandProcess;

public class ItemOrderConfirmUpdateFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. get -> order_num
		// 2. dao od선언
		// 3. od select
		// 4. 저장 -> pageunm, order

		try {
			request.setCharacterEncoding("utf-8");
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			String pageNum = request.getParameter("pageNum");

			
			
			OrderDao od = OrderDao.getInstance();
			Order order = od.select(order_num);

						
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("order", order);
			request.setAttribute("order_num", order_num);

			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "itemOrderConfirm/itemOrderConfirmUpdateForm.jsp";
	}

}
