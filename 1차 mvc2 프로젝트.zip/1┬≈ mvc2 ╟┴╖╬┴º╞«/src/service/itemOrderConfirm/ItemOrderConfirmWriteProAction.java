package service.itemOrderConfirm;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import service.CommandProcess;

public class ItemOrderConfirmWriteProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. get -> order_num, pageNum
		// 2. oderDao od Instance
		// 3. int result = od.insert(board);
		// 4. 저장 ->
		try {

			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			Order order = new Order();

			order.setOrder_company(request.getParameter("order_company"));
			order.setItem_count(Integer.parseInt(request.getParameter("item_count")));
			order.setItem_code(Integer.parseInt(request.getParameter("item_code")));

			ItemDao id = ItemDao.getInstance();
			Item item = id.select(item_code); 
			
			OrderDao od = OrderDao.getInstance();
			int result = od.insert(order, item);
			request.setAttribute("result", result);
			request.setAttribute("pageNum", pageNum);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "itemOrderConfirm/itemOrderConfirmWritePro.jsp";
	}

}
