package service.itemOrderConfirm;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Order;
import dao.OrderDao;
import service.CommandProcess;

public class ItemOrderConfirmUpdateProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");
			String order_num_ = request.getParameter("order_num");
			int order_num = Integer.parseInt(order_num_);
			String order_company = request.getParameter("order_company");
			int item_count = Integer.parseInt(request.getParameter("item_count"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			int dept_num = Integer.parseInt(request.getParameter("dept_num"));
			
			Order order = new Order();

			order.setOrder_num(order_num);
			order.setOrder_company(order_company);
			order.setItem_count(item_count);
			order.setItem_code(item_code);
			order.setDept_num(dept_num);

			OrderDao od = OrderDao.getInstance();

			int result = od.update(order);

			request.setAttribute("result", result);
			request.setAttribute("order_num", order.getOrder_num());
			request.setAttribute("pageNum", pageNum);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "itemOrderConfirm/itemOrderConfirmUpdatePro.jsp";
	}

}
