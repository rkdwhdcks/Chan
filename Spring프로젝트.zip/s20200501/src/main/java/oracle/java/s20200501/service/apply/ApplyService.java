package oracle.java.s20200501.service.apply;

import java.util.List;

import oracle.java.s20200501.model.Apply;
import oracle.java.s20200501.model.Member;

public interface ApplyService {

	int apply(Apply apply);

	List<Member> applyGet(int board_num);

	int mbCheck(Apply apply);

}
