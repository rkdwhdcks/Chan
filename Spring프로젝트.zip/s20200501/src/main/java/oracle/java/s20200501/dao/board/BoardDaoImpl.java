package oracle.java.s20200501.dao.board;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Board;

@Repository
public class BoardDaoImpl implements BoardDao {

	@Autowired
	private SqlSession session;

	@Override
	public int fbTotal(Board board) {
		System.out.println("다오 -> 자유게시판 총갯수");

		return session.selectOne("fbTotal",board);
	}

	@Override
	public List<Board> fbList(Board board) {
		System.out.println("다오 -> 자유게시판 리스트");

		return session.selectList("fbList", board);
	}

	@Override
	public int fbWrite(Board board) {
		System.out.println("다오 -> 자유게시판 글쓰기 before");
        int result = 0;
        try {	    		       	
        	System.out.println(board.getBoard_file());
        	result = session.insert("fbWrite", board);
        	System.out.println(board.getBoard_num());
        	System.out.println(board.getBoard_kind());
        	System.out.println(board.getBoard_content());
        	System.out.println(board.getBoard_type());
     	} catch (Exception e) {
			System.out.println("다오.fbWrite e.getMessage()->"+e.getMessage());
		}
       
		return result;
	}

	@Override
	public Board fbDetail(int board_num) {
		System.out.println("다오 -> 자유게시판 상세보기");
		
		return session.selectOne("fbDetail", board_num);
	}

	@Override
	public int fbHit(int board_num) {
		System.out.println("다오 -> 자유게시판 조회수");
		
		return session.update("fbHit", board_num);
	}

	@Override
	public int fbUp(int board_num) {
		System.out.println("다오 -> 자유게시판 추천");
		
		return session.update("fbUp", board_num);
	}

	@Override
	public Board fbUpdateForm(int board_num) {
		System.out.println("다오 -> 자유게시판 수정폼");
		
		return session.selectOne("fbUpdateForm", board_num);
	}

	@Override
	public int fbUpdate(Board board) {
		System.out.println("다오 -> 자유게시판 수정");
		
		return session.update("fbUpdate", board);
	}

	@Override
	public int fbDelete(int board_num) {
		System.out.println("다오 -> 자유게시판 삭제");
		return session.delete("fbDelete", board_num);
	}

	@Override
	public int mbtotal(Board board) {
		System.out.println("BoardDaoImpl total...");
		
		return session.selectOne("mbtotal", board);
	}

	@Override
	public List<Board> mblist(Board board) {
		System.out.println("BoardDaoImpl list...");
		
		return session.selectList("mblistAll", board);
	}

	@Override
	public int meetingInsert(Board board) {
		System.out.println("BoardDaoImpl meetingInsert...");
		
		return session.insert("meetingInsert", board);
	}

	@Override
	public Board meetingDetail(int board_num) {
		System.out.println("BoardDaoImpl meetingDetail board_num->" + board_num);
		
		return session.selectOne("meetingDetail", board_num);
	}

	@Override
	public int mbUpHit(int board_num) {
		System.out.println("BoardDaoImpl upHit board_num->" + board_num);
		
		return session.update("mbupHit", board_num);
	}

	@Override
	public Board meetingUpdateForm(int board_num) {
		System.out.println("BoardDaoImpl meetingUpdateForm");
		
		return session.selectOne("mbUpdateForm", board_num);
	}

	@Override
	public int meetingUpdateForm(Board board) {
		System.out.println("BoardDaoImpl meetingUpdate");
		
		return session.update("mbUpdate", board);
	}

	@Override
	public int meetingDelete(int board_num) {
		System.out.println("BoardDaoImpl meetingDelete");
		
		return session.delete("mbDelete", board_num);
	}
	
	@Override
	public int gbtotal() {
		System.out.println("gbtotal...");
		return session.selectOne("gbtotal");
	}

	@Override
	public List<Board> gblist(Board board) {
		System.out.println("gblist(Board)...");
		return session.selectList("gblist", board);	
	}

	@Override
	public Board gbdetail(int board_num) {
		System.out.println("gbdetail(board_num)...");
		return session.selectOne("gbdetail", board_num);
	}

	@Override
	public int gbupdate(Board board) {
		System.out.println("gbupdate(board)...");
		return session.update("gbupdate", board);
	}

	@Override
	public int boardinsert(Board board) {
		System.out.println("gbwrite(board)...");
		return session.insert("gbinsert", board);
	}

	@Override
	public int gbdelete(int board_num) {
		System.out.println("gbdelete(board)...");
		return session.delete("gbdelete", board_num);
	}
}
