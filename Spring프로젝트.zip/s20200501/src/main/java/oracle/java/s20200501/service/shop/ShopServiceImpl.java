package oracle.java.s20200501.service.shop;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.shop.ShopDao;
import oracle.java.s20200501.model.Shop;

@Service
public class ShopServiceImpl implements ShopService {
	@Autowired
	private ShopDao sd;

	@Override
	public int stotal(Shop shop) {
		System.out.println("stotal start........");
		return sd.stotal(shop);
	}

	@Override
	public List<Shop> list(Shop shop) {
		System.out.println("서비스 리스트임");
		return sd.shoplist(shop);
	}

	@Override
	public int s_insert(Shop shop) {
		System.out.println("서비스 s인서트");
		return sd.s_insert(shop);
	}

	@Override
	public Shop s_num(String s_n) {
		System.out.println("서비스 샾 네임1");
		return sd.s_select(s_n);
	}

	@Override
	public Shop sdetail(int shop_num) {
		// TODO Auto-generated method stub
		return sd.sdetail(shop_num);
	}

	@Override
	public double shop_staravg(Shop shop) {
		// TODO Auto-generated method stub
		return sd.shop_staravg(shop);
	}

	@Override
	public List<Shop> mbshopList() {
		System.out.println("BoardServiceImpl total...");

		return sd.mbshopList();
	}

	@Override
	public int s_update(Shop shop) {
		// TODO Auto-generated method stub
		return sd.supdate(shop);
	}

	@Override
	public int shopdelete(int shop_num) {
		System.out.println("샵 딜리트 서비스");
		return sd.shopdelete(shop_num);
	}

	@Override
	public List<Shop> cklist(Shop shop) {
		// TODO Auto-generated method stub
		return sd.cklist(shop);
	}

}
