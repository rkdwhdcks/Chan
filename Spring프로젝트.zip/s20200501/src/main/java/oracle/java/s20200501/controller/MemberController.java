package oracle.java.s20200501.controller;

import oracle.java.s20200501.model.Favor;

import oracle.java.s20200501.model.M_favor;
import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.MemberVO;

import oracle.java.s20200501.service.favor.FavorService;
import oracle.java.s20200501.service.m_favor.M_favorService;
import oracle.java.s20200501.service.member.MemberService;


import java.io.File;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.activation.FileDataSource;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class MemberController {
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private MemberService ms;
	
	@Autowired
	private FavorService fs;
	
	@Autowired
	private M_favorService m_fs;
	
	@Autowired
	private JavaMailSender mailSender;
	
	@RequestMapping(value = "loginForm")
	public String loginForm(Model model) {
		System.out.println("loginForm Start...");
		return "member/loginForm";
	}
	
//	@RequestMapping(value = "login", method=RequestMethod.POST)
//	public String login(Member member, Model model, HttpServletRequest request) {
//		System.out.println("login Start...");
//		Member member3 = null;
//		String id = request.getParameter("memberId");
//		String pwd = request.getParameter("memberPw");
//		member.setMember_id(id);
//		member.setMember_pw(pwd);
//		member3 = ms.select(member);
//		System.out.println("login End...");
//		System.out.println("nickname->" + member3.getNickname());
//		model.addAttribute("member3", member3);
//		return "loginForm";
//	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(HttpServletRequest request, Member member, Model model, HttpSession session, M_favor mf) {
		System.out.println("login Start...");
		String id = request.getParameter("memberId");
		String pwd = request.getParameter("memberPw");
		member.setMember_id(id);
		member.setMember_pw(pwd);
		try {			
			Member member3 = ms.select(member);
			System.out.println("login End...");
			System.out.println("nickname->" + member3.getNickname());
			session.setAttribute("session", member3);
			Member sessionCheck = (Member) session.getAttribute("session");
			System.out.println("세션안에 들어있는값 확인@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			System.out.println(sessionCheck.getMember_id());
			String member_id = member3.getMember_id();
			System.out.println(member_id);

			List<M_favor> M_favorlist = m_fs.M_favorList(member_id);
			System.out.println(M_favorlist);
//			List<S_favor> shopnumlist = s_fs.ShopNumList(M_favorlist);
			
			model.addAttribute("member3", sessionCheck);
			return "redirect:main.do";
		} catch (Exception e) {
			return "member/loginError";
		}
	}
	
	@RequestMapping(value = "logout")
	public String logout(HttpSession session) {
		System.out.println("logout Start...");
		session.invalidate();
		return "redirect:main.do";
	}
	
	@RequestMapping(value = "joinForm")
	public String joinForm(Model model) {
		System.out.println("joinForm Start...");
		return "member/joinForm";
	}
	
	@RequestMapping(value = "mypage")
	public String mypage(Member member, String member_id, Model model) {
		System.out.println("mypage Start...");
		return "member/mypage";
	}

	@RequestMapping(value = "joinForm2")
	public String joinForm2(Favor favor, Member member, Model model) {
		System.out.println("joinForm2 Start...");
		List<Favor> favorlist = fs.list(favor) ;
		System.out.println("favorlist-->" + favorlist);
		model.addAttribute("favorlist", favorlist);
//		List<Member> list = ms.list(member);
//		model.addAttribute("list", list);
//		System.out.println("list->" + list);
		return "member/joinForm2";
	}
	
//	@RequestMapping(value = "join", method=RequestMethod.POST)
//	public String join(HttpServletRequest request, Member member, Model model) {
//		System.out.println("join Start...");
//		System.out.println("member.getMember_id->"+member.getMember_id());
//		int result = ms.insert(member);
//		System.out.println("ms.insert(member) CNT -->" + result);
//		return "redirect:loginForm.do";
//	}
	
	@RequestMapping(value = "join", method=RequestMethod.POST)
	public String join(HttpServletRequest request, MemberVO memberVO, Model model, Favor favor, M_favor m_favor) {
		Member member = null;
		try {
			MemberVO memberVO3 = ms.insertMemberVO(memberVO);
			if (memberVO == null) {
				System.out.println("memberVO NULL");
			} else {
				System.out.println("RmemberVO.getOmember_id()->" + memberVO.getOmember_id());
				System.out.println("RmemberVO.getOdname()->" + memberVO.getOmember_name());
				System.out.println("RmemberVO.getOloc()->" + memberVO.getOmember_sex());
				List<Member> list = ms.list(member);
				model.addAttribute("list", list);
				System.out.println("list->" + list);
				model.addAttribute("msg", "정상 입력 되었습니다 ^^");
				model.addAttribute("member", memberVO3);
				model.addAttribute("member1", memberVO);
				

				String member_idd = memberVO.getOmember_id();
				
				String[] mf_list = request.getParameterValues("favor_num");
				String[] m_num10 = new String[mf_list.length];
				for(int i=0; i<mf_list.length;i++) {
					m_num10[i] = member_idd;
				}
				
				HashMap<String, Object> hmap = new HashMap<String, Object>();
				M_favor m_favor1 = new M_favor();
				
				//List<String> last = Arrays.asList(sf_list[i],Integer.toString(s_num10[i]));
				for(int i =0; i<mf_list.length;i++) {
					hmap.put("favor_num",mf_list[i]);
					hmap.put("member_id", m_num10[i]);
			
					m_fs.mfinsert(hmap);
				
				
				 
				}
			}
			return "member/joinForm3";
		} catch (Exception e) {
			return "member/joinError";
		}
	}
	
	@RequestMapping(value = "findIdForm")
	public String findIdForm(Model model) {
		System.out.println("findId Start...");
		return "member/findIdForm";
	}
	
	
	@RequestMapping(value = "findId", method=RequestMethod.POST)
	public String findId(HttpServletRequest request, Model model) {
		System.out.println("findIdForm Start...");
		Member member = new Member();
		System.out.println("nickname empty? ->" + member.getNickname());
		member.setNickname(request.getParameter("nickname"));
		System.out.println("nickname? ->" + member.getNickname());
		String id = ms.findid(member);
		System.out.println("id ->" + id);
		model.addAttribute("id", id);
		return "member/findIdForm2";
	}
	
	@RequestMapping(value = "findPwForm")
	public String findPwForm(Model model) {
		System.out.println("findPwForm Start...");
		return "member/findPwForm";
	}
	
	@RequestMapping(value = "findPwForm2")
	public String findPwForm2(HttpServletRequest request, Model model) {
		System.out.println("findPwForm2 Start...");
		Member member = new Member();
		String id = request.getParameter("memberId");
		member.setMember_id(id);
		String email = ms.findPw(member);
		System.out.println("email -->" + email);
		
		System.out.println("mailSending");
		String tomail = email;
		System.out.println("tomail -->" + tomail);
		String setfrom = "youngjunkim9595@gmail.com";
		String title = "숡 입니다";
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
			messageHelper.setFrom(setfrom);
			messageHelper.setTo(tomail);
			messageHelper.setSubject(title);
			String tempPassword = (int) (Math.random() * 999999) + 1 + "";
			messageHelper.setText("임시 비밀번호입니다 : " + tempPassword);
			
			Member member1 = new Member();
			member1.setMember_id(id);
			member1.setMember_pw(tempPassword);
			int k = ms.pwUpdate(member1);
			
			FileDataSource dataSource = new FileDataSource("c:\\log\\숡.jpg");
			messageHelper.addAttachment(MimeUtility.encodeText("airport.png", "UTF-8", "B"), dataSource);
			mailSender.send(message);
			model.addAttribute("check", 1);
		} catch (Exception e) {
			System.out.println(e);
			model.addAttribute("check", 2);
		}
		model.addAttribute("email", email);
		return "member/findPwForm2";
	}
	
	@RequestMapping(value = "modifyForm1")
	public String modifyForm(Model model) {
		System.out.println("modifyForm Start...");
		return "member/modifyForm1";
	}
	
	@RequestMapping(value = "modify")
	public String modify(MultipartFile file, String path, HttpSession session, HttpServletRequest request, Member member, Model model) throws Exception {
		System.out.println("modify Start...");
		
		HashMap<String, Object> memberMap = new HashMap<String, Object>();
		
		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
		System.out.println("pictureUpload Start...");
		logger.info("originalName: " + file.getOriginalFilename());
		logger.info("size:" + file.getSize());
		logger.info("contentType: " + file.getContentType());
		String savedName = uploadFile(file.getOriginalFilename(), file.getBytes(), uploadPath);
		logger.info("savedName: " + savedName);
		String mem_img = "upload/" + savedName;
		System.out.println(mem_img);
		model.addAttribute("savedName", savedName);
		
		memberMap.put("member_id", request.getParameter("member_id"));
		memberMap.put("member_pw", request.getParameter("member_pw"));
		memberMap.put("member_kakaoid", request.getParameter("member_kakaoid"));
		memberMap.put("member_loc", request.getParameter("member_loc"));
		memberMap.put("member_age", request.getParameter("member_age"));
		memberMap.put("member_sex", request.getParameter("member_sex"));
		memberMap.put("member_alcohol", request.getParameter("member_alcohol"));
		memberMap.put("member_rank", request.getParameter("member_rank"));
		memberMap.put("nickname", request.getParameter("nickname"));
		memberMap.put("photo", mem_img);
		memberMap.put("member_name", request.getParameter("member_name"));
		memberMap.put("member_email", request.getParameter("member_email"));

		Member sessionCheck = (Member) session.getAttribute("session");
		System.out.println("session id -->" + sessionCheck.getMember_id());
		memberMap.put("ori_member_id", sessionCheck.getMember_id());

		System.out.println(memberMap);
		int k = ms.modifyUpdate(memberMap);
		System.out.println("int k = " + k);
		model.addAttribute("k", k);
		
		return "member/modifyForm2";
		
		
	}
	
	@RequestMapping(value="confirm")
	public String confirm(String member_id, Model model) {
		Member member = ms.joinDetail(member_id);
		model.addAttribute("member_id", member_id);
		if (member != null) {
			model.addAttribute("msg", "중복된 아이디입니다");
			return "forward:joinForm2.do";
		} else {			
			model.addAttribute("msg", "가능한 아이디입니다");
			return "forward:joinForm2.do";
		}
	}

//	@RequestMapping(value="pictureUpload", method = RequestMethod.POST)
//	public String pictureUpload(HttpServletRequest request, MultipartFile file, String path, Model model) throws Exception {
//		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
//		System.out.println("pictureUpload Start...");
//		logger.info("originalName: " + file.getOriginalFilename());
//		logger.info("size:" + file.getSize());
//		logger.info("contentType: " + file.getContentType());
//		String savedName = uploadFile(file.getOriginalFilename(), file.getBytes(), uploadPath);
//		logger.info("savedName: " + savedName);
//		String mem_img = "upload\\" + savedName;
//		System.out.println(mem_img);
//		model.addAttribute("savedName", savedName);
//		
////		int k = ms.addImg(mem_img);
//		
//		return "redirect:modifyForm1.do";
//	}
//	
	private String uploadFile(String originalName, byte[] fileData, String uploadPath) throws Exception {
		UUID uid = UUID.randomUUID();
		System.out.println("uploadPath->" + uploadPath);
		File fileDirectory = new File(uploadPath);
		if (!fileDirectory.exists()) {
			fileDirectory.mkdirs();
			System.out.println("업로드용 폴서 생성 : " + uploadPath);
		}
		
		String savedName = uid.toString() + "_" + originalName;
		File target = new File(uploadPath, savedName);
		FileCopyUtils.copy(fileData, target);
		return savedName;
	}

//	테이블 3개 조인 쿼리문
//	select shop_img from shop
//	where shop_num = (select shop_num from s_favor s left outer join m_favor m ON m.favor_num = s.favor_num
//	where member_id = 'test1111');
	
}
