package oracle.java.s20200501.model;

public class S_favor {
	private int favor_num;
	private int shop_num;
	public int getFavor_num() {
		return favor_num;
	}
	public void setFavor_num(int favor_num) {
		this.favor_num = favor_num;
	}
	public int getShop_num() {
		return shop_num;
	}
	public void setShop_num(int shop_num) {
		this.shop_num = shop_num;
	}
	
}