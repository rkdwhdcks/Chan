package oracle.java.s20200501.service.m_favor;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.m_favor.M_favorDao;
import oracle.java.s20200501.model.M_favor;

@Service
public class M_favorServiceImpl implements M_favorService {

	@Autowired
	private M_favorDao m_fd;

	@Override
	public int mfinsert(HashMap<String, Object> hmap) {
		// TODO Auto-generated method stub
		return m_fd.mfinsert(hmap);
	}

	@Override
	public List<M_favor> M_favorList(String member_id) {
		// TODO Auto-generated method stub
		return m_fd.M_favorList(member_id);
	}
}
