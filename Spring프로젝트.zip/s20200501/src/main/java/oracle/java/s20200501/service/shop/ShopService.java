package oracle.java.s20200501.service.shop;

import java.util.List;

import oracle.java.s20200501.model.Shop;

public interface ShopService {

	int stotal(Shop shop);

	List<Shop> list(Shop shop);

	Shop sdetail(int shop_num);

	int s_insert(Shop shop);

	Shop s_num(String s_n);

	double shop_staravg(Shop shop);

	List<Shop> mbshopList();

	int s_update(Shop shop);

	int shopdelete(int shop_num);

	List<Shop> cklist(Shop shop);
}
