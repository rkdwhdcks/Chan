package oracle.java.s20200501.dao.star_point;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Star_point;

@Repository
public class Star_pointDaoImpl implements Star_pointDao {
	@Autowired
	private SqlSession session;

	@Override
	public List<Star_point> reviewList(int shop_num) {
		System.out.println("리뷰리스트 DAOIMPL");
		return session.selectList("reviewList", shop_num);
	}

	@Override
	public int rtotal(int shop_num) {
		// TODO Auto-generated method stub
		return session.selectOne("rtotal", shop_num);
	}

	@Override
	public int reviewWrite(Star_point star_point) {
		// TODO Auto-generated method stub
		return session.insert("reviewWrite", star_point);
	}

	@Override
	public int s_pointSum(int shop_num) {
		// TODO Auto-generated method stub
		return session.selectOne("s_pointSum", shop_num);
	}

	@Override
	public int s_pointCount(int shop_num) {
		// TODO Auto-generated method stub
		return session.selectOne("s_pointCount", shop_num);
	}

	@Override
	public int review(int shop_num) {
		System.out.println("리뷰딜리트 다오");
		return session.delete("review_delete",shop_num);
	}
	@Override
	   public int reviewModify(Star_point star_point) {
	      // TODO Auto-generated method stub
	      return session.update("reviewModify", star_point);
	   }

	   @Override
	   public int reviewDelete(Star_point star_point) {
	      // TODO Auto-generated method stub
	      return session.delete("reviewDelete", star_point);
	   }
	
	
}
