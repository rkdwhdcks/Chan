package oracle.java.s20200501.service.favor;

import java.util.List;

import oracle.java.s20200501.model.Favor;

public interface FavorService {

	List<Favor> list(Favor favor);

	
	List<Favor> favorList(int shop_num);

	  List<Favor> colList(int shop_num);
}
