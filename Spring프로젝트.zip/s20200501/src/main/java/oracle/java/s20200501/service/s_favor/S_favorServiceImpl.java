package oracle.java.s20200501.service.s_favor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.s_favor.S_favorDao;
import oracle.java.s20200501.model.S_favor;


@Service
public class S_favorServiceImpl implements S_favorService {
	@Autowired
	private S_favorDao s_fd;

/*	@Override
	public int sfinsert(int s_num, String[] sf_list) {
		// TODO Auto-generated method stub
		return s_fd.sfinsert(s_num,sf_list);
	}*/

	@Override
	public int delete(int s_num) {
		return s_fd.sdelete(s_num);
		
	}

@Override
public int sfinsert(HashMap<String, Object> hmap) {
	// TODO Auto-generated method stub
	return s_fd.sfinsert(hmap);
}

@Override
public int sfavordelete(int shop_num) {
	System.out.println("s빼버 딜리트서비스");
	return s_fd.sfavordelete(shop_num);
}




	

}
