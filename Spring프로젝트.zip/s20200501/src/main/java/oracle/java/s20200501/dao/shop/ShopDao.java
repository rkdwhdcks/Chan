package oracle.java.s20200501.dao.shop;

import java.util.List;

import oracle.java.s20200501.model.Shop;

public interface ShopDao {

	int stotal(Shop shop);

	List<Shop> shoplist(Shop shop);

	int s_insert(Shop shop);

	Shop s_select(String s_n);

	Shop sdetail(int shop_num);

	double shop_staravg(Shop shop);

	List<Shop> mbshopList();

	int supdate(Shop shop);

	int shopdelete(int shop_num);

	List<Shop> cklist(Shop shop);
}
