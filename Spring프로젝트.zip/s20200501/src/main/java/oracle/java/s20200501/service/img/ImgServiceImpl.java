package oracle.java.s20200501.service.img;



import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.img.ImgDao;
import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.Shop;
@Service
public class ImgServiceImpl implements ImgService{
	@Autowired
	private ImgDao id;

	

	@Override
	   public List<Img> list(int shop_num) {
	      
	      return id.imglist(shop_num);
	   }

	@Override
	public int imgdelete(int s_num) {
		// TODO Auto-generated method stub
		return id.imgdelete(s_num);
	}

	@Override
	public int fileuplod(HashMap<String, Object> imgmap) {
			return id.fileuplod(imgmap);
		
	}

	@Override
	public int allimgdelete(int shop_num) {
		System.out.println("이미지 딜리트 서비스");
		return id.allimgdelete(shop_num);
		
	}





	



	



	
}
