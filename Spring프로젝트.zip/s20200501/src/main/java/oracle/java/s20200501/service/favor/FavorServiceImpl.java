package oracle.java.s20200501.service.favor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.favor.FavorDao;
import oracle.java.s20200501.model.Favor;

@Service
public class FavorServiceImpl implements FavorService {
	@Autowired
	private FavorDao fd;

	@Override
	public List<Favor> list(Favor favor) {
		System.out.println("서비스 패퍼 리스트");
		return fd.favorlist(favor);
	}

	@Override
	   public List<Favor> favorList(int shop_num) {
	      
	      return fd.favorList(shop_num);
	   }

	   @Override
	   public List<Favor> colList(int shop_num) {
	      // TODO Auto-generated method stub
	      return fd.colList(shop_num);
	   }


	
}
