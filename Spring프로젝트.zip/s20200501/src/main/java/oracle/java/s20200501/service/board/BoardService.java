package oracle.java.s20200501.service.board;

import java.util.List;

import oracle.java.s20200501.model.Board;

public interface BoardService {

	int fbTotal(Board board);

	List<Board> fbList(Board board);

	int fbWrite(Board board);

	Board fbDetail(int board_num);

	int fbHit(int board_num);

	int fbUp(int board_num);

	Board fbUpdateForm(int board_num);

	int fbUpdate(Board board);

	int fbDelete(int board_num);
	
	int mbtotal(Board board);
	
	List<Board> mblist(Board board);

	int meetingInsert(Board board);

	Board meetingDetail(int board_num);

	int mbUpHit(int board_num);

	Board meetingUpdateForm(int board_num);

	int meetingUpdate(Board board);

	int meetingDelete(int board_num);
	
	int gbtotal();

	List<Board> gblist(Board board);

	Board gbdetail(int board_num);

	int gbupdate(Board board);

	int gbwrite(Board board);

	int gbdelete(int board_num);
}
