package oracle.java.s20200501.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.Reply;
import oracle.java.s20200501.service.reply.ReplyService;

@Controller
public class ReplyController {
	
	@Autowired
	private ReplyService rs;
	
	@RequestMapping(value = "fbrWrite", method=RequestMethod.POST)
	public String fbrWrite(Model model, int board_num, Reply reply, HttpSession session) {
		System.out.println("댓글쓰기 시작...");
		
		Member m = (Member) session.getAttribute("session");
		reply.setMember_id(m.getMember_id());
		reply.setBoard_num(board_num);
		
		System.out.println(reply.getMember_id());
		System.out.println(reply.getBoard_num());
		
		int result = rs.fbrWrite(reply);
		return "redirect:fbDetail.do?board_num="+board_num;
	}
	
	@RequestMapping(value ="fbrrWrite", method=RequestMethod.POST)
	public String fbrrWrite(Model model, Reply reply, int board_num, int reply_group, int reply_step, int reply_indent, HttpSession session) {
		System.out.println("댓글에 답글시작...");
		
		Member m = (Member) session.getAttribute("session");
		reply.setMember_id(m.getMember_id());
		reply.setBoard_num(board_num);
		reply.setReply_group(reply_group);
		
		System.out.println(reply.getReply_group());
		
		int res = rs.replyShape(reply);
		
		int result = rs.fbrrWrite(reply);
		
		return "redirect:fbDetail.do?board_num="+board_num;
	}
	
	@RequestMapping(value="fbrDelete")
	public String fbrDelete(Model model, int reply_num, int board_num) {
		System.out.println("controller fbrDelete start...");
		System.out.println(reply_num);
		System.out.println(board_num);

		int result = rs.fbrDelete(reply_num);

		return "redirect:fbDetail.do?board_num="+board_num;
	}
	
	@RequestMapping(value="getFbrModify", produces = "application/text;charset=UTF-8")
	@ResponseBody
	public String getReviewUpdate(int r_num, String r_content, Model model) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("rn", r_num);
		hm.put("rc", r_content);
		System.out.println("getReviewUpdate Start...");
		System.out.println("getReviewUpdate rw_num->"+r_num );
		System.out.println("getReviewUpdate rw_content->"+r_content );
		// 수정 성공하면  1, 실패시 0
		int result = rs.fbrUpdate(hm);
		
		
		return r_content;
	
	}
}
