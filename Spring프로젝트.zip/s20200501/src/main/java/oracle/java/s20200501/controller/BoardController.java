package oracle.java.s20200501.controller;

import java.io.File;
import java.sql.Date;
import java.util.List;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import oracle.java.s20200501.model.Apply;
import oracle.java.s20200501.model.Board;
import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.Reply;
import oracle.java.s20200501.model.Shop;
import oracle.java.s20200501.service.Paging;
import oracle.java.s20200501.service.apply.ApplyService;
import oracle.java.s20200501.service.board.BoardService;
import oracle.java.s20200501.service.reply.ReplyService;
import oracle.java.s20200501.service.shop.ShopService;

@Controller
public class BoardController {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	@Autowired
	private BoardService bs;

	@Autowired
	private ShopService ss;

	@Autowired
	private ReplyService rs;

	@Autowired
	private ApplyService as;

	@RequestMapping(value = "freeBoard")
	public String freeBoard(Model model, Board board, String currentPage, HttpServletRequest request) {
		System.out.println("freeBoard List Start...");
		System.out.println("겟필드1" + board.getField());
		if (board.getField() == null) {
			System.out.println("겟필드2" + board.getField());
			board.setField("board_title");
		}
		/*
		 * System.out.println("겟필드3" + board.getField()); }else if
		 * (board.getField().equals("1")) { System.out.println("1 e들어왓니");
		 * board.setField("nickName");
		 * 
		 * }else board.setField("board_title");
		 */if (board.getSearch() == null) {
			board.setSearch("");
		}
		System.out.println("BoardController 겟필드" + board.getField());
		System.out.println("BoardController getSearch" + board.getSearch());
		System.out.println("BoardController getSearch" + board.getSearch());
		int total = bs.fbTotal(board);
		System.out.println("total " + total);
		Paging pg = new Paging(total, currentPage);
		board.setStart(pg.getStart());
		board.setEnd(pg.getEnd());
		List<Board> fbList = bs.fbList(board);
		model.addAttribute("fbList", fbList);
		model.addAttribute("pg", pg);
		model.addAttribute("board", board);

		return "freeBoard/freeBoard";
	}

	@RequestMapping(value = "fbWriteForm")
	public String fbWriteForm(Model model) {
		System.out.println("freeBoard Write Start...");

		return "freeBoard/fbWriteForm";
	}

	@RequestMapping(value = "fbWrite", method = RequestMethod.POST)
	public String fbWrite(Model model, HttpServletRequest request, MultipartFile board_file, String path,
			HttpSession session) {
		System.out.println("자유게시판 글쓰기 시작");
		Board board = new Board();
		Member m = (Member) session.getAttribute("session");
		board.setMember_id(m.getMember_id());
		System.out.println("보드 : 아이디 -> " + board.getMember_id());
		board.setBoard_content(request.getParameter("board_content"));
		board.setBoard_title(request.getParameter("board_title"));
		board.setBoard_kind(request.getParameter("board_kind"));
		String savedName = null;
		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
		logger.info("originalName -> " + board_file.getOriginalFilename());
		logger.info("size -> " + board_file.getSize());
		logger.info("contentType -> " + board_file.getContentType());
		try {
			savedName = uploadFile(board_file.getOriginalFilename(), board_file.getBytes(), uploadPath);
		} catch (Exception e) {
			System.out.println("Exception -> " + e.getMessage());
			e.printStackTrace();
		}

		logger.info("savedName -> " + savedName);
		board.setBoard_file("upload\\" + savedName);
		int result = bs.fbWrite(board);

		return "redirect:freeBoard.do";

	}

	private String uploadFile(String originalName, byte[] fileData, String uploadPath) throws Exception {
		UUID uid = UUID.randomUUID();
		// requestPath = requestPath + "/resources/image";
		System.out.println("uploadPath -> " + uploadPath);
		// Directory 생성
		File fileDirectory = new File(uploadPath);
		if (!fileDirectory.exists()) {
			fileDirectory.mkdirs();
			System.out.println("업로드용 폴더 생성 -> " + uploadPath);
		}

		String savedName = uid.toString() + "_" + originalName;
		// String path1 =
		// "C:\\spring\\springSrc\\.metadata\\.plugins\\org.eclipse.wst.server
		File target = new File(uploadPath, savedName);
		FileCopyUtils.copy(fileData, target);
		return savedName;
	}

	@RequestMapping(value = "fbDetail")
	public String fbDetail(Model model, int board_num, Reply reply, HttpSession session) {
		System.out.println("board controller fbDtail.....");

		int hit = bs.fbHit(board_num);

		Board board = bs.fbDetail(board_num);

		List<Reply> fbrList = rs.fbrList(board_num);

		model.addAttribute("board", board);
		model.addAttribute("fbrList", fbrList);

		return "freeBoard/fbDetail";
	}

	@RequestMapping(value = "fbUp")
	public String fbUp(Model model, int board_num) {
		System.out.println("board controller fbUp...");

		int up = bs.fbUp(board_num);

		System.out.println("오나?");

		model.addAttribute("board_num", board_num);

		return "redirect:fbDetail.do";
	}

	@RequestMapping(value = "fbUpdateForm")
	public String fbUpdateForm(Model model, int board_num) {
		System.out.println("board controller fbupdateform");

		Board board = bs.fbUpdateForm(board_num);
		model.addAttribute("board", board);

		return "freeBoard/fbUpdateForm";

	}

	@RequestMapping(value = "fbUpdate", method = RequestMethod.POST)
	public String fbUpdate(Model model, HttpServletRequest request, MultipartFile board_file, String path) {
		System.out.println("자유게시판 글수정 시작");
		Board board = new Board();
		board.setBoard_kind(request.getParameter("board_kind"));
		System.out.println(board.getBoard_kind());
		board.setBoard_content(request.getParameter("board_content"));
		System.out.println(board.getBoard_content());
		board.setBoard_title(request.getParameter("board_title"));
		System.out.println(board.getBoard_title());
		board.setBoard_num(Integer.parseInt(request.getParameter("board_num")));
		System.out.println("board_num -> " + board.getBoard_num());
		String savedName = null;
		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
		logger.info("originalName -> " + board_file.getOriginalFilename());
		logger.info("size -> " + board_file.getSize());
		logger.info("contentType -> " + board_file.getContentType());
		try {
			savedName = uploadFile(board_file.getOriginalFilename(), board_file.getBytes(), uploadPath);
		} catch (Exception e) {
			System.out.println("Exception -> " + e.getMessage());
			e.printStackTrace();
		}

		logger.info("savedName -> " + savedName);
		board.setBoard_file("upload\\" + savedName);
		int result = bs.fbUpdate(board);

		return "redirect:freeBoard.do";
	}

	@RequestMapping(value = "fbDelete")
	public String fbDelete(Model model, int board_num) {
		System.out.println("controller fbDelete start...");

		int result = bs.fbDelete(board_num);

		return "redirect:freeBoard.do";
	}

	@RequestMapping(value = "meetingList")
	public String meetingList(Board board, String currentPage, Model model, HttpServletRequest request) {
		System.out.println("meetingList Start...");

		if (board.getField() == null) {
			board.setField("board_title");
		}
		if (board.getSearch() == null) {
			board.setSearch("");
		}
		int total = bs.mbtotal(board);
		System.out.println("Controller meeting list total-> " + total);
		Paging pg = new Paging(total, currentPage);
		board.setStart(pg.getStart());
		board.setEnd(pg.getEnd());
		List<Board> list = bs.mblist(board);

		model.addAttribute("list", list);
		model.addAttribute("pg", pg);
		model.addAttribute("board", board);

		return "meeting/meetingList";
	}

	@RequestMapping(value = "meetingWriteForm")
	public String meetingWriteForm(HttpServletRequest request, Model model) {
		System.out.println("Controller meeting Write Form...");

		HttpSession session = request.getSession();
		Member m = (Member) session.getAttribute("session");
		String member_id = (String) m.getMember_id();
		// shop list 가져와야함
		List<Shop> shopList = ss.mbshopList();

		model.addAttribute("shopList", shopList);
		model.addAttribute("member_id", member_id);

		return "meeting/meetingWriteForm";
	}

	@RequestMapping(value = "meetingWrite", method = RequestMethod.POST)
	public String meetingWrite(Board board, Model model) {
		System.out.println("Controller meeting Write....");

		String time = board.getStime();
		board.setTime(java.sql.Timestamp.valueOf(time));

		int result = bs.meetingInsert(board);

		if (result > 0)
			return "redirect:meetingList.do";
		else {
			model.addAttribute("msg", "입력 실패");
			return "forward:meetingWriteForm.do";
		}
	}

	@RequestMapping(value = "meetingDetail")
	public String meetingDetail(HttpServletRequest request, int board_num, Model model) {
		HttpSession session = request.getSession();
		System.out.println("session->" + session);

		int hit = bs.mbUpHit(board_num);
		Board board = bs.meetingDetail(board_num);
		List<Member> member = as.applyGet(board_num);

		try {
			Member m = (Member) session.getAttribute("session");
			String member_id = (String) m.getMember_id();
			String bmember_id = (String) board.getMember_id();

			System.out.println("member_id->" + member_id);
			System.out.println("bmember_id->" + bmember_id);
			// 내용비교할때는 equals
			/*
			 * int result = 0; if(member_id.equals(bmember_id)) { System.out.println("똑같음");
			 * result = 1; } else { System.out.println("안똑같음"); result = 0; }
			 * System.out.println("result->" + result);
			 */
			model.addAttribute("member_id", member_id);
			model.addAttribute("bmember_id", bmember_id);
			model.addAttribute("member", member);
		} catch (Exception e) {
			return "redirect:loginForm.do";
		}
		model.addAttribute("board", board);
		// model.addAttribute("result", result);

		return "meeting/meetingDetail";
	}

	@RequestMapping(value = "meetingUpdateForm")
	public String meetingUpdateForm(HttpSession session, int board_num, Model model) {
		System.out.println("Controller meetingUpdateForm...");
		
		Member m = (Member) session.getAttribute("session");
		m.getMember_id();
		model.addAttribute("member_id", m.getMember_id());

		List<Shop> shopList = ss.mbshopList();
		Board board = bs.meetingUpdateForm(board_num);

		model.addAttribute("shopList", shopList);
		model.addAttribute("board", board);

		return "meeting/meetingUpdateForm";
	}

	@RequestMapping(value = "meetingUpdate", method = RequestMethod.POST)
	public String meetingUpdate(Board board, Model model) {
		System.out.println("Controller meetingUpdate....");

		String time = board.getStime();
		board.setTime(java.sql.Timestamp.valueOf(time));

		int result = bs.meetingUpdate(board);

		if (result > 0)
			return "redirect:meetingList.do";
		else {
			model.addAttribute("msg", "입력 실패");
			return "forward:meetingUpdateForm.do";
		}
	}

	@RequestMapping(value = "meetingDelete")
	public String meetingDelete(int board_num, Model model) {
		System.out.println("Controller meetingDelete board_num->" + board_num);

		int result = bs.meetingDelete(board_num);

		System.out.println("result->" + result);

		return "redirect:meetingList.do";
	}

	@RequestMapping(value = "meetingApply")
	public String meetingApply(int board_num, String member_id, Model model, HttpServletResponse response) {
		System.out.println("identifyController meetingApply member_id->" + member_id);
		System.out.println("apply board_num->" + board_num);
		Apply apply = new Apply();
		apply.setBoard_num(board_num);
		apply.setBoard_type("번개");
		apply.setMember_id(member_id);

		int result = as.mbCheck(apply);
		if (result != 1) {
			as.apply(apply);
			model.addAttribute("msg", "신청되었습니다.");
		} else {
			model.addAttribute("msg", "이미 신청되었습니다.");
		}

		return "forward:meetingDetail.do?board_num=" + board_num;

	}

	@RequestMapping(value = "GradeBoard")
	public String GradeBoard(Board board, String currentPage, Model model) {
		System.out.println("BoardController list()...");

		int total = bs.gbtotal();
		// 리스트의 총 갯수
		Paging pg = new Paging(total, currentPage);
		// 페이징을 하기 위한 작업
		board.setStart(pg.getStart());
		// 리스트의 첫번째 실행
		board.setEnd(pg.getEnd());
		// 리스트의 끝마침

		List<Board> list = bs.gblist(board);
		model.addAttribute("gblist", list);
		model.addAttribute("pg", pg);

		return "gradeBoard/gblist";
		// WEB-INF/views/gradeBoard/gblist.jsp
	}

	@RequestMapping("gbdetail")
	public String gbdetail(Model model, int board_num, HttpServletRequest request) {
		System.out.println("BoardController gbdetail()");
		
		/*
		 * //session 받아오기 HttpSession session = request.getSession(); String id =
		 * (String) session.getAttribute("id");
		 */

		Board board = bs.gbdetail(board_num);
		model.addAttribute("board", board);

		return "gradeBoard/gbdetail";
	}

	@RequestMapping(value = "gbupdateForm")
	public String gbupdateForm(Model model, int board_num) {
		System.out.println("BoardController gbupdateForm()");

		Board board = bs.gbdetail(board_num);
		model.addAttribute("board", board);

		return "/gradeBoard/gbupdateForm";
	}

	@RequestMapping(value = "gbupdate")
	public String gbupdate(Model model, Board board) {
		System.out.println("BoardController gbupdate()");

		int result = bs.gbupdate(board);

		return "redirect:GradeBoard.do";
	}

	@RequestMapping("gbwriteForm")
	public String gbwriteForm(Model model) {
		System.out.println("BoardController gbwriteForm()");

		return "/gradeBoard/gbwriteForm";
	}

	@RequestMapping(value = "gbwrite", method = RequestMethod.POST)
	public String gbwrite(Board board, Model model, HttpSession session) {
		System.out.println("BoardController gbwrite()");
		Member m = (Member) session.getAttribute("session");
		board.setMember_id(m.getMember_id());
		int result = bs.gbwrite(board);
		if (result > 0) {
			return "redirect:GradeBoard.do";
		} else {
			return "forward:gbwriteForm.do";
		}

	}

	@RequestMapping("gbdelete")
	public String gbdelete(int board_num) {
		System.out.println("BoardController gbdelete()");

		int result = bs.gbdelete(board_num);
		return "redirect:GradeBoard.do";
	}
}
