package oracle.java.s20200501.dao.member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.M_favor;
import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.MemberVO;
//import oracle.java.s20200501.service.HashMap;
import oracle.java.s20200501.model.S_favor;

public interface MemberDao {

	Member select(Member member);

	List<Member> list(Member member);

//	int insert(Member member);

	MemberVO insertMemberVO(MemberVO memberVO);

	String findid(Member member);

	String findPw(Member member);

	int pwUpdate(Member member1);

	int modifyUpdate(HashMap<String, Object> member);

	Member joinDetail(String member_id);



}
