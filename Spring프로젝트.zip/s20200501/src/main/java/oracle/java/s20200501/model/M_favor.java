package oracle.java.s20200501.model;

public class M_favor {
	private int favor_num;
	private String member_id;
	
	public int getFavor_num() {
		return favor_num;
	}
	public void setFavor_num(int favor_num) {
		this.favor_num = favor_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	
}
