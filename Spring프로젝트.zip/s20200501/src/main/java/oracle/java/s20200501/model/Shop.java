package oracle.java.s20200501.model;

public class Shop {
	private int shop_num;
	private String shop_name;
	private String shop_menu;
	private String shop_size;
	private String shop_loc;
	private String shop_time;
	private String shop_cost;
	private int shop_div;
	private double shop_staravg;
	private String shop_floc;

	private String search;
	private String keyword;
	private String pageNum;
	private int start;
	private int end;
	private String kind;
	private String loc;

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getShop_floc() {
		return shop_floc;
	}

	public void setShop_floc(String shop_floc) {
		this.shop_floc = shop_floc;
	}

	public double getShop_staravg() {
		return shop_staravg;
	}

	public void setShop_staravg(double shop_staravg) {
		this.shop_staravg = shop_staravg;
	}

	public int getShop_num() {
		return shop_num;
	}

	public void setShop_num(int shop_num) {
		this.shop_num = shop_num;
	}

	public String getShop_name() {
		return shop_name;
	}

	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}

	public String getShop_menu() {
		return shop_menu;
	}

	public void setShop_menu(String shop_menu) {
		this.shop_menu = shop_menu;
	}

	public String getShop_size() {
		return shop_size;
	}

	public void setShop_size(String shop_size) {
		this.shop_size = shop_size;
	}

	public String getShop_loc() {
		return shop_loc;
	}

	public void setShop_loc(String shop_loc) {
		this.shop_loc = shop_loc;
	}

	public String getShop_time() {
		return shop_time;
	}

	public void setShop_time(String shop_time) {
		this.shop_time = shop_time;
	}

	public String getShop_cost() {
		return shop_cost;
	}

	public void setShop_cost(String shop_cost) {
		this.shop_cost = shop_cost;
	}

	public int getShop_div() {
		return shop_div;
	}

	public void setShop_div(int shop_div) {
		this.shop_div = shop_div;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getPageNum() {
		return pageNum;
	}

	public void setPageNum(String pageNum) {
		this.pageNum = pageNum;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;

	}
}
