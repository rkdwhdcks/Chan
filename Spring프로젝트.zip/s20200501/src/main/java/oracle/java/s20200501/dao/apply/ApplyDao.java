package oracle.java.s20200501.dao.apply;

import java.util.List;

import oracle.java.s20200501.model.Apply;
import oracle.java.s20200501.model.Member;

public interface ApplyDao {

	int apply(Apply apply);

	List<Member> applyGet(int board_num);

	int mbCheck(Apply apply);

}
