package oracle.java.s20200501.service.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.board.BoardDao;
import oracle.java.s20200501.model.Board;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDao bd;

	@Override
	public int fbTotal(Board board) {
		System.out.println("서비스 -> 자유게시판 총 갯수");
		return bd.fbTotal(board);
	}

	@Override
	public List<Board> fbList(Board board) {
		System.out.println("서비스 -> 자유게시판 리스트");
		return bd.fbList(board);
	}

	@Override
	public int fbWrite(Board board) {
		System.out.println("서비스 -> 자유게시판 글쓰기");
		return bd.fbWrite(board);
	}

	@Override
	public Board fbDetail(int board_num) {
		System.out.println("서비스 -> 자유게시판 상세보기");

		return bd.fbDetail(board_num);
	}

	@Override
	public int fbHit(int board_num) {
		System.out.println("서비스 -> 자유게시판 조회수");

		return bd.fbHit(board_num);
	}

	@Override
	public int fbUp(int board_num) {
		System.out.println("서비스 -> 자유게시판 추천");

		return bd.fbUp(board_num);
	}

	@Override
	public Board fbUpdateForm(int board_num) {
		System.out.println("서비스 -> 자유게시판 수정폼");

		return bd.fbUpdateForm(board_num);
	}

	@Override
	public int fbUpdate(Board board) {
		System.out.println("서비스 -> 자유게시판 수정하기");

		return bd.fbUpdate(board);
	}

	@Override
	public int fbDelete(int board_num) {
		System.out.println("서비스 -> 자유게시판 삭제");
		return bd.fbDelete(board_num);
	}

	@Override
	public int mbtotal(Board board) {
		System.out.println("BoardServiceImpl total...");

		return bd.mbtotal(board);
	}

	@Override
	public List<Board> mblist(Board board) {
		System.out.println("BoardServiceImpl list...");

		return bd.mblist(board);
	}

	@Override
	public int meetingInsert(Board board) {
		System.out.println("BoardServiceImpl meetingInsert...");

		return bd.meetingInsert(board);
	}

	@Override
	public Board meetingDetail(int board_num) {
		System.out.println("BoardServiceImpl detail...");

		return bd.meetingDetail(board_num);
	}

	@Override
	public int mbUpHit(int board_num) {
		System.out.println("BoardServiceImpl upHit...");

		return bd.mbUpHit(board_num);
	}

	@Override
	public Board meetingUpdateForm(int board_num) {
		System.out.println("BoardServiceImpl meetingUpdateForm...");

		return bd.meetingUpdateForm(board_num);
	}

	@Override
	public int meetingUpdate(Board board) {
		System.out.println("BoardServiceImpl meetingUpdate...");

		return bd.meetingUpdateForm(board);
	}

	@Override
	public int meetingDelete(int board_num) {
		System.out.println("BoardServiceImpl meetingDelete...");

		return bd.meetingDelete(board_num);
	}
	
	
	
	@Override
	public int gbtotal() {
		System.out.println("gbtotal...");
		return bd.gbtotal();
	}

	@Override
	public List<Board> gblist(Board board) {
		System.out.println("gblist...");
		return bd.gblist(board);
	}

	@Override
	public Board gbdetail(int board_num) {
		System.out.println("gbdetail...");
		return bd.gbdetail(board_num);
	}

	@Override
	public int gbupdate(Board board) {
		System.out.println("gbupdate...");
		return bd.gbupdate(board);
	}

	@Override
	public int gbwrite(Board board) {
		System.out.println("gbwrite...");
		return bd.boardinsert(board);
	}

	@Override
	public int gbdelete(int board_num) {
		System.out.println("gbdelete...");
		return bd.gbdelete(board_num);
	}
}
