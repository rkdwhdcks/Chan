package oracle.java.s20200501.dao.board;

import java.util.List;

import oracle.java.s20200501.model.Board;

public interface BoardDao {

	int fbTotal(Board board);

	List<Board> fbList(Board board);

	int fbWrite(Board board);

	Board fbDetail(int board_num);

	int fbHit(int board_num);

	int fbUp(int board_num);

	Board fbUpdateForm(int board_num);

	int fbUpdate(Board board);

	int fbDelete(int board_num);
	
	Board meetingUpdateForm(int board_num);

	int meetingUpdateForm(Board board);

	int meetingDelete(int board_num);

	int mbUpHit(int board_num);

	Board meetingDetail(int board_num);

	int mbtotal(Board board);

	List<Board> mblist(Board board);

	int meetingInsert(Board board);
	
	int gbtotal();

	List<Board> gblist(Board board);

	Board gbdetail(int board_num);

	int gbupdate(Board board);

	int boardinsert(Board board);

	int gbdelete(int board_num);
}
