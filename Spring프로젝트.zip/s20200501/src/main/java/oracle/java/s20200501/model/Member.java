package oracle.java.s20200501.model;

public class Member {
	private String member_id;
	private String member_pw;
	private String member_kakaoid;
	private String member_loc;
	private int member_age;
	private String member_sex;
	private int member_alcohol;
	private String member_rank;
	private String nickname;
	private String photo;
	private String member_name;
	private String member_email;
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMember_pw() {
		return member_pw;
	}
	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}
	public String getMember_kakaoid() {
		return member_kakaoid;
	}
	public void setMember_kakaoid(String member_kakaoid) {
		this.member_kakaoid = member_kakaoid;
	}
	public String getMember_loc() {
		return member_loc;
	}
	public void setMember_loc(String member_loc) {
		this.member_loc = member_loc;
	}
	public int getMember_age() {
		return member_age;
	}
	public void setMember_age(int member_age) {
		this.member_age = member_age;
	}
	public String getMember_sex() {
		return member_sex;
	}
	public void setMember_sex(String member_sex) {
		this.member_sex = member_sex;
	}
	public int getMember_alcohol() {
		return member_alcohol;
	}
	public void setMember_alcohol(int member_alcohol) {
		this.member_alcohol = member_alcohol;
	}
	public String getMember_rank() {
		return member_rank;
	}
	public void setMember_rank(String member_rank) {
		this.member_rank = member_rank;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_email() {
		return member_email;
	}
	public void setMember_email(String member_email) {
		this.member_email = member_email;
	}

	
}
