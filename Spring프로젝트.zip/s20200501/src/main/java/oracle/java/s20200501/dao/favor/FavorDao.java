package oracle.java.s20200501.dao.favor;

import java.util.List;

import oracle.java.s20200501.model.Favor;

public interface FavorDao {

	List<Favor> favorlist(Favor favor);
	List<Favor> favorList(int shop_num);

	 List<Favor> colList(int shop_num);
}
