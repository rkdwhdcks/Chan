package oracle.java.s20200501.dao.img;

import java.sql.Connection;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;



import javax.naming.Context;
import javax.naming.InitialContext;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Img;


@Repository
public class ImgDaoImpl implements ImgDao {
	@Autowired
	private SqlSession session;

	DataSource dataSource;
	Connection con;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;


	@Override
	public int fileuplod(HashMap<String, Object> imgmap) {
		return session.insert("fileinsert", imgmap);

	}

	

	@Override
	   public List<Img> imglist(int shop_num) {
	      System.out.println("ImgDao imglist 옴~~~~~");
	      return session.selectList("imglist",shop_num);
	   }

	@Override
	public int imgdelete(int s_num) {
		return session.delete("imgdelete",s_num);
	}

	@Override
	public int allimgdelete(int shop_num) {
		System.out.println("이미지 딜리트다오");
		return session.delete("imgdelete",shop_num);
	}


}
