package oracle.java.s20200501.dao.m_favor;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.M_favor;

@Repository
public class M_favorDaoImpl implements M_favorDao {

	@Autowired
	private SqlSession session;

	@Override
	public int mfinsert(HashMap<String, Object> hmap) {
		// TODO Auto-generated method stub
		return session.insert("mfinsert",hmap);
	}

	@Override
	public List<M_favor> M_favorList(String member_id) {
		// TODO Auto-generated method stub
		return session.selectList("M_favorList", member_id);
	}
	
	
}
