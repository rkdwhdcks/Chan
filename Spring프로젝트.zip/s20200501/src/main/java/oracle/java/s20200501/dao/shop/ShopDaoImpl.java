package oracle.java.s20200501.dao.shop;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Shop;

@Repository
public class ShopDaoImpl implements ShopDao {
	@Autowired
	private SqlSession session;

	@Override
	public int stotal(Shop shop) {
		System.out.println("dao total 임");
		
		if (shop.getKind() ==null) {
			if(shop.getLoc()==null) {
				System.out.println("stotal1");
				return session.selectOne("stotal1",shop);
			}else {
			System.out.println("stotal2");
				return session.selectOne("stotal2",shop);
			}
			
		}else {
			if(shop.getLoc()==null) {
				
				System.out.println("stotal3");
				return session.selectOne("stotal3",shop);
				
			}else {
				System.out.println("stotal4");
				return session.selectOne("stotal4",shop);
			}
		}
	}

	@Override
	public List<Shop> shoplist(Shop shop) {

		if (shop.getKind() ==null) {
			if(shop.getLoc()==null) {
				System.out.println("slist1");
				return session.selectList("slist1",shop);
			}else {
			System.out.println("slist2");
				return session.selectList("slist2",shop);
			}
			
		}else {
			if(shop.getLoc()==null) {
				System.out.println("slist3");
				return session.selectList("slist3",shop);
				
			}else {
				System.out.println("slist4");
				return session.selectList("slist4",shop);
			}
		}
	}
	

	@Override
	public int s_insert(Shop shop) {
		System.out.println("다오 s 인서트");
		
	return session.insert("s_insert",shop);
	}

	@Override
	public Shop s_select(String s_n) {
			System.out.println("sslect 넘버가져오기");
			
		return session.selectOne("sslect",s_n);
	}
	  @Override
	   public Shop sdetail(int shop_num) {
	      System.out.println("dao shop sdetail 임");
	      return session.selectOne("sdetail", shop_num);
	   }

	@Override
	public double shop_staravg(Shop shop) {
		// TODO Auto-generated method stub
		return session.update("shop_staravg", shop);
	}
	
	@Override
	public List<Shop> mbshopList() {
		System.out.println("ShopDaoImpl shopList...");
		
		return session.selectList("mbshopList");
	}

	@Override
	public int supdate(Shop shop) {
		System.out.println("shop 내용 업데이트");
		return session.update("sh_update", shop);
	}

	@Override
	public int shopdelete(int shop_num) {
		System.out.println("샵 딜리트 다오");
		return session.delete("sh_delete",shop_num);
	}

	@Override
	public List<Shop> cklist(Shop shop) {
		// TODO Auto-generated method stub
		return session.selectList("cklist",shop);
	}

}
