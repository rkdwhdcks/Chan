package oracle.java.s20200501.model;

public class Favor {
	private int favor_num;
	private String col;
	private String favor_kind;
	public int getFavor_num() {
		return favor_num;
	}
	public void setFavor_num(int favor_num) {
		this.favor_num = favor_num;
	}
	public String getCol() {
		return col;
	}
	public void setCol(String col) {
		this.col = col;
	}
	public String getFavor_kind() {
		return favor_kind;
	}
	public void setFavor_kind(String favor_kind) {
		this.favor_kind = favor_kind;
	}
	
}