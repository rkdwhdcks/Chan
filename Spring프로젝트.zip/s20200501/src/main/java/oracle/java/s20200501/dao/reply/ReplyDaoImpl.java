package oracle.java.s20200501.dao.reply;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Reply;

@Repository
public class ReplyDaoImpl implements ReplyDao {

	@Autowired
	SqlSession session;
	
	@Override
	public int fbrWrite(Reply reply) {
		System.out.println("자게댓글 다오 시작...");
		
		return session.insert("fbrWrite", reply);
	}

	@Override
	public List<Reply> fbrList(int board_num) {
		System.out.println("자게댓글 리스트 다오 시작...");
		
		return session.selectList("fbrList", board_num);
	}

	@Override
	public int replyShape(Reply reply) {
		System.out.println("자게댓글 댓글달기 다오1...");
		
		return session.update("replyShape", reply);
	}

	@Override
	public int fbrrWrite(Reply reply) {
		System.out.println("자게댓글 댓글달기 다오2...");
		
		return session.insert("fbrrWrite", reply);
	}

	@Override
	public int fbrDelete(int reply_num) {
		System.out.println("자게 댓글 댓글 삭제 다오...");
		
		return session.delete("fbrDelete", reply_num);
	}

	@Override
	public int fbrUpdate(HashMap<String, Object> hm) {
		System.out.println("자게 댓글 수정 다오....");
		
		return session.update("fbrUpdate", hm);
	}

}
