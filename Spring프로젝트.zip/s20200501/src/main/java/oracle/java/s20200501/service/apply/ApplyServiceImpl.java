package oracle.java.s20200501.service.apply;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.apply.ApplyDao;
import oracle.java.s20200501.model.Apply;
import oracle.java.s20200501.model.Member;

@Service
public class ApplyServiceImpl implements ApplyService {
	
	@Autowired
	private ApplyDao ad;

	@Override
	public int apply(Apply apply) {
		System.out.println("ApplyServiceImpl apply...");

		return ad.apply(apply);
	}

	@Override
	public List<Member> applyGet(int board_num) {
		System.out.println("ApplyServiceImpl applyGet...");

		return ad.applyGet(board_num);
	}

	@Override
	public int mbCheck(Apply apply) {
		System.out.println("ApplyServiceImpl Check...");

		return ad.mbCheck(apply);
	}
}
