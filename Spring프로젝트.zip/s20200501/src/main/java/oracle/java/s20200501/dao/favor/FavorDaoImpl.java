package oracle.java.s20200501.dao.favor;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Favor;
@Repository
public class FavorDaoImpl implements FavorDao {
	@Autowired
	private SqlSession session;

	@Override
	public List<Favor> favorlist(Favor favor) {
		System.out.println("페버리스트 다오");
		return session.selectList("favorlist", favor);
	}
	@Override
	   public List<Favor> favorList(int shop_num) {
	      
	      return session.selectList("favorList", shop_num);
	   }

	   @Override
	   public List<Favor> colList(int shop_num) {
	      // TODO Auto-generated method stub
	      return session.selectList("colList", shop_num);
	   }

}
