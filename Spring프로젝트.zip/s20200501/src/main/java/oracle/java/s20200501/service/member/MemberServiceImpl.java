package oracle.java.s20200501.service.member;

import oracle.java.s20200501.dao.member.MemberDao;
import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.M_favor;
import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.MemberVO;
import oracle.java.s20200501.model.S_favor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao md;
	
	@Override
	public Member select(Member member) {
		System.out.println("MemberServiceImpl select...");
		System.out.println("MemberServiceImpl select getMember_id->" + member.getMember_id());
		System.out.println("MemberServiceImpl select getMember_pw->" + member.getMember_pw());
	return md.select(member);
	}

	@Override
	public List<Member> list(Member member) {
		System.out.println("MemberServiceImpl list...");
		return md.list(member);
	}

//	@Override
//	public int insert(Member member) {
//		System.out.println("MemberServiceImpl insert...");
//		return md.insert(member);
//	}

	@Override
	public MemberVO insertMemberVO(MemberVO memberVO) {
		System.out.println("MemberServiceImpl insertMemberVO...");
		return md.insertMemberVO(memberVO);
	}

	@Override
	public String findid(Member member) {
		System.out.println("MemberServiceImpl findid...");
		return md.findid(member);
	}

	@Override
	public String findPw(Member member) {
		System.out.println("MemberServiceImpl findPw...");
		return md.findPw(member);
	}

	@Override
	public int pwUpdate(Member member1) {
		System.out.println("MemberServiceImpl pwUpdate...");
		return md.pwUpdate(member1);
	}

	@Override
	public int modifyUpdate(HashMap<String, Object> member) {
		System.out.println("MemberServiceImpl modifyUpdate...");
		return md.modifyUpdate(member);
	}

	@Override
	public Member joinDetail(String member_id) {
		System.out.println("MemberServiceImpl joinDetail...");
		return md.joinDetail(member_id);
	}


}
