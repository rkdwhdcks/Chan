package oracle.java.s20200501.dao.apply;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Apply;
import oracle.java.s20200501.model.Member;

@Repository
public class ApplyDaoImpl implements ApplyDao {
	
	@Autowired
	private SqlSession session;

	@Override
	public int apply(Apply apply) {
		System.out.println("ApplyDaoImpl apply");
		
		return session.insert("apply", apply);
	}

	@Override
	public List<Member> applyGet(int board_num) {
		System.out.println("ApplyDaoImpl applyGet");
		
		return session.selectList("applyList", board_num);
	}

	@Override
	public int mbCheck(Apply apply) {
		System.out.println("ApplyDaoImpl mbCheck");
		
		return session.selectOne("mbCheck",apply);
	}
}
