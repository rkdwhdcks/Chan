package oracle.java.s20200501.service.reply;

import java.util.HashMap;
import java.util.List;

import oracle.java.s20200501.model.Reply;

public interface ReplyService {

	int fbrWrite(Reply reply);

	List<Reply> fbrList(int board_num);

	int replyShape(Reply reply);

	int fbrrWrite(Reply reply);

	int fbrDelete(int reply_num);

	int fbrUpdate(HashMap<String, Object> hm);

}
