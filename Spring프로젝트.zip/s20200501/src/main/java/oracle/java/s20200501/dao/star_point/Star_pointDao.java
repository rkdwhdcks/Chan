package oracle.java.s20200501.dao.star_point;

import java.util.List;

import oracle.java.s20200501.model.Star_point;

public interface Star_pointDao {

	List<Star_point> reviewList(int shop_num);

	int rtotal(int shop_num);

	int reviewWrite(Star_point star_point);

	int s_pointSum(int shop_num);

	int s_pointCount(int shop_num);

	int review(int shop_num);
	int reviewModify(Star_point star_point);

	   int reviewDelete(Star_point star_point);

}
