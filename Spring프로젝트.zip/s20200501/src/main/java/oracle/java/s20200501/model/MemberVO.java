package oracle.java.s20200501.model;

public class MemberVO {
	private String member_id;
	private String member_pw;
	private String member_kakaoid;
	private String member_loc;
	private int member_age;
	private String member_sex;
	private int member_alcohol;
	private String member_rank;
	private String nickname;
	private String photo;
	private String member_name;
	private String member_email;
	
	
	
	private String omember_id;
	private String omember_pw;
	private String omember_kakaoid;
	private String omember_loc;
	private int omember_age;
	private String omember_sex;
	private int omember_alcohol;
	private String omember_rank;
	private String onickname;
	private String ophoto;
	private String omember_name;
	private String omember_email;
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMember_pw() {
		return member_pw;
	}
	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}
	public String getMember_kakaoid() {
		return member_kakaoid;
	}
	public void setMember_kakaoid(String member_kakaoid) {
		this.member_kakaoid = member_kakaoid;
	}
	public String getMember_loc() {
		return member_loc;
	}
	public void setMember_loc(String member_loc) {
		this.member_loc = member_loc;
	}
	public int getMember_age() {
		return member_age;
	}
	public void setMember_age(int member_age) {
		this.member_age = member_age;
	}
	public String getMember_sex() {
		return member_sex;
	}
	public void setMember_sex(String member_sex) {
		this.member_sex = member_sex;
	}
	public int getMember_alcohol() {
		return member_alcohol;
	}
	public void setMember_alcohol(int member_alcohol) {
		this.member_alcohol = member_alcohol;
	}
	public String getMember_rank() {
		return member_rank;
	}
	public void setMember_rank(String member_rank) {
		this.member_rank = member_rank;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_email() {
		return member_email;
	}
	public void setMember_email(String member_email) {
		this.member_email = member_email;
	}
	
	
	
	public String getOmember_id() {
		return omember_id;
	}
	public void setOmember_id(String omember_id) {
		this.omember_id = omember_id;
	}
	public String getOmember_pw() {
		return omember_pw;
	}
	public void setOmember_pw(String omember_pw) {
		this.omember_pw = omember_pw;
	}
	public String getOmember_kakaoid() {
		return omember_kakaoid;
	}
	public void setOmember_kakaoid(String omember_kakaoid) {
		this.omember_kakaoid = omember_kakaoid;
	}
	public String getOmember_loc() {
		return omember_loc;
	}
	public void setOmember_loc(String omember_loc) {
		this.omember_loc = omember_loc;
	}
	public int getOmember_age() {
		return omember_age;
	}
	public void setOmember_age(int omember_age) {
		this.omember_age = omember_age;
	}
	public String getOmember_sex() {
		return omember_sex;
	}
	public void setOmember_sex(String omember_sex) {
		this.omember_sex = omember_sex;
	}
	public int getOmember_alcohol() {
		return omember_alcohol;
	}
	public void setOmember_alcohol(int omember_alcohol) {
		this.omember_alcohol = omember_alcohol;
	}
	public String getOmember_rank() {
		return omember_rank;
	}
	public void setOmember_rank(String omember_rank) {
		this.omember_rank = omember_rank;
	}
	public String getOnickname() {
		return onickname;
	}
	public void setOnickname(String onickname) {
		this.onickname = onickname;
	}
	public String getOphoto() {
		return ophoto;
	}
	public void setOphoto(String ophoto) {
		this.ophoto = ophoto;
	}
	public String getOmember_name() {
		return omember_name;
	}
	public void setOmember_name(String omember_name) {
		this.omember_name = omember_name;
	}
	public String getOmember_email() {
		return omember_email;
	}
	public void setOmember_email(String omember_email) {
		this.omember_email = omember_email;
	}
	
	
}
