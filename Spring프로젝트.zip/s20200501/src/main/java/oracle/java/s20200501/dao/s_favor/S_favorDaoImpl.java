package oracle.java.s20200501.dao.s_favor;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200501.model.Favor;
import oracle.java.s20200501.model.S_favor;

@Repository
public class S_favorDaoImpl implements S_favorDao {
	@Autowired
	private SqlSession session;
	DataSource dataSource;
	Connection con;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	
/*	@Override
	public int sfinsert(int s_num, String[] sf_list) {
		System.out.println("체크박스 인서트");
		String sql = "insert into s_favor values(?,?)";
		System.out.println("에스큐엘 문 -> " + sql);
		int result = 0;

		try {
			for (int i = 0; i < sf_list.length; i++) {
				con = dataSource.getConnection();
				System.out.println("con -> " + con);
				pstmt = con.prepareStatement(sql);
				System.out.println("sptmt -> " + pstmt);
				pstmt.setString(1,sf_list[i]);
				pstmt.setInt(2, s_num);
				result = pstmt.executeUpdate();
			}

		} catch (SQLException e) {
			System.out.println("에러다에러!!!! -> " + e.getMessage());
		}
		return result ;
	}*/
	@Override
	public int sdelete(int s_num) {
		// TODO Auto-generated method stub
		return session.delete("ssdelete",s_num);
	}

	@Override
	public int sfinsert(HashMap<String, Object> hmap) {
		// TODO Auto-generated method stub
		return session.insert("sfinsert",hmap);
	}

	@Override
	public int sfavordelete(int shop_num) {
		System.out.println("s빼버 딜리트다오");
		return session.delete("ssdelete",shop_num);
	}

	/*@Override
	public int sfinsert(int s_num, String[] sf_list) {
		// TODO Auto-generated method stub
		return session.insert("sfinsert",s_num,sf_list);
	}*/
	
}
