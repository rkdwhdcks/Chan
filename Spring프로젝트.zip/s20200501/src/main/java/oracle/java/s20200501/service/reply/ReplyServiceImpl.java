package oracle.java.s20200501.service.reply;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.reply.ReplyDao;
import oracle.java.s20200501.model.Reply;

@Service
public class ReplyServiceImpl implements ReplyService {

	@Autowired
	ReplyDao rd;
	
	@Override
	public int fbrWrite(Reply reply) {
		System.out.println("자게댓글 서비스 시작...");
		
		return rd.fbrWrite(reply);
	}

	@Override
	public List<Reply> fbrList(int board_num) {
		System.out.println("자게댓글 리스트 서비스 시작...");
		
		return rd.fbrList(board_num);
	}

	@Override
	public int replyShape(Reply reply) {
		System.out.println("자게댓글 댓글달기 서비스1...");
		
		return rd.replyShape(reply);
	}

	@Override
	public int fbrrWrite(Reply reply) {
		System.out.println("자게댓글 댓글달기 서비스2...");
		
		return rd.fbrrWrite(reply);
	}

	@Override
	public int fbrDelete(int reply_num) {
		System.out.println("자게 댓글 삭제 서비스...");
		
		return rd.fbrDelete(reply_num);
	}

	@Override
	public int fbrUpdate(HashMap<String, Object> hm) {
		System.out.println("자게 댓글 수정 서비스...");
		return rd.fbrUpdate(hm);
	}

}
