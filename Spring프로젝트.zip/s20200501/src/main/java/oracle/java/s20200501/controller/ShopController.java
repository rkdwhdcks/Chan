package oracle.java.s20200501.controller;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.Serializable;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import oracle.java.s20200501.model.Favor;
import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.S_favor;
import oracle.java.s20200501.model.Shop;
import oracle.java.s20200501.model.Star_point;
import oracle.java.s20200501.service.Paging;
import oracle.java.s20200501.service.favor.FavorService;
import oracle.java.s20200501.service.img.ImgService;
import oracle.java.s20200501.service.s_favor.S_favorService;
import oracle.java.s20200501.service.shop.ShopService;
import oracle.java.s20200501.service.star_point.Star_pointService;
import oracle.net.aso.p;

@Controller
public class ShopController {

	private static final Logger logger = LoggerFactory.getLogger(ShopController.class);

	@Autowired
	private ShopService ss;
	@Autowired
	private ImgService is;
	@Autowired
	private FavorService fs;
	@Autowired
	private S_favorService sfs;
	@Autowired
	private Star_pointService sps;

	@RequestMapping(value = "shoplist", method = RequestMethod.GET)
	public String shoplist(Shop shop, String currentPage, Model model, Favor favor, HttpServletRequest request) {
		System.out.println("EmpController list start....");

		if (shop.getSearch() == null) {
			shop.setSearch("");
		}

		String[] chkplay = request.getParameterValues("favor_kind");
		String[] chkloc = request.getParameterValues("shop_floc");
		System.out.println("chkplay->" + chkplay);
		if(chkplay != null) {
		String kind = "";
		for (int i = 0; i < chkplay.length; i++) {
			kind += "'" + chkplay[i] + "'";
			if (i < chkplay.length - 1) {
				kind += ",";
			}
		}
		System.out.println("카인드->>"+kind);
		shop.setKind(kind);
		}
		if (chkloc != null) {
		String loc = "";
		for (int i = 0; i < chkloc.length; i++) {
			loc += "'" + chkloc[i] + "'";
			if (i < chkloc.length - 1) {	
				loc += ",";
			}
		}
		
		shop.setLoc(loc);
		System.out.println("지역->>>"+loc);
		}
		
		int stotal = ss.stotal(shop);
		System.out.println("Shop list  total-->>" + stotal);
		System.out.println("Shop list currentPage ->" + currentPage);
		Paging spg = new Paging(stotal, currentPage);
		shop.setStart(spg.getStart());
		shop.setEnd(spg.getEnd());
		List<Shop> shoplist = ss.list(shop);
		System.out.println("shop 리스트 ");
		List<Shop> checklist = ss.cklist(shop);
		System.out.println("checklist");
		List<Favor> favorlist = fs.list(favor);
		System.out.println("favorlist");
		System.out.println("shoplist ->" + shoplist);
		model.addAttribute("shoplist", shoplist);
		model.addAttribute("spg", spg);
		model.addAttribute("cklist", checklist);
		model.addAttribute("favorlist", favorlist);
		return "shop/shoplist";
	}

	@RequestMapping(value = "writeForm", method = RequestMethod.GET)
	public String writeDeptIn(Model model, Favor favor) {
		System.out.println("writeForm Start");
		List<Favor> favorlist = fs.list(favor);
		System.out.println("favorlist-->" + favorlist);
		model.addAttribute("favorlist", favorlist);

		return "shop/ShopWriteForm";
	}

	@RequestMapping(value = "uploadForm", method = RequestMethod.POST)
	public String uploadForm(Shop shop, Model model, MultipartHttpServletRequest request, Favor favor, S_favor s_favor)
			throws Exception {
		System.out.println("이곳은 모든 업로드에 결정체");

		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
		System.out.println("uploadForm POST Start");
		List<String> img_size = new ArrayList<String>();
		List<MultipartFile> fileList = request.getFiles("img1");
		for (MultipartFile mf : fileList) {
			logger.info("originalName: " + mf.getOriginalFilename());
			logger.info("size: " + mf.getSize());
			logger.info("contentType: " + mf.getContentType());
			String savedName = null;
			try {

				savedName = uploadFile(mf.getOriginalFilename(), mf.getBytes(), uploadPath);
				logger.info("savedName: " + savedName);
				if (mf.getSize() >= 1) {
					savedName = uploadFile(mf.getOriginalFilename(), mf.getBytes(), uploadPath);
					logger.info("savedName: " + savedName);

					String new_img = "upload\\" + savedName;
					img_size.add(new_img);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			System.out.println("이미지 사이즈" + img_size);
		}

		shop.setShop_name(request.getParameter("shop_name"));
		shop.setShop_menu(request.getParameter("shop_menu"));
		shop.setShop_size(request.getParameter("shop_size"));
		shop.setShop_loc(request.getParameter("shop_loc"));
		shop.setShop_time(request.getParameter("shop_time"));
		shop.setShop_cost(request.getParameter("shop_cost"));

		int result = ss.s_insert(shop);
		String s_n = shop.getShop_name();
		System.out.println("샾 ㅇ리ㅡㅁ는멀까요~" + s_n);
		shop = ss.s_num(s_n);

		int s_num = shop.getShop_num();
		String[] sf_list = request.getParameterValues("favor_num");
		int[] s_num10 = new int[sf_list.length];
		for (int i = 0; i < sf_list.length; i++) {
			s_num10[i] = s_num;
		}

		S_favor s_favor1 = new S_favor();
		HashMap<String, Object> hmap = new HashMap<String, Object>();

		// List<String> last = Arrays.asList(sf_list[i],Integer.toString(s_num10[i]));
		for (int i = 0; i < sf_list.length; i++) {
			hmap.put("favor_num", sf_list[i]);
			hmap.put("shop_num", s_num10[i]);

			sfs.sfinsert(hmap);

		}

		System.out.println("샵넘 -> " + shop.getShop_num());

		int sf_num = favor.getFavor_num();

		System.out.println("sf_list의모든것->" + sf_list);

		int[] s_num9 = new int[img_size.size()];
		for (int i = 0; i < img_size.size(); i++) {
			s_num9[i] = s_num;
		}
		HashMap<String, Object> imgmap = new HashMap<String, Object>();
		for (int i = 0; i < img_size.size(); i++) {
			imgmap.put("shop_num", s_num9[i]);
			imgmap.put("simg", img_size.get(i));

			is.fileuplod(imgmap);
		}
		return "redirect:shoplist.do";

	}

	@RequestMapping(value = "sdetail")
	public String sdetail(int shop_num, Model model, String currentPage, Img img) {
		System.out.println("ShopController sdetail start...");
		Shop shop = ss.sdetail(shop_num);
		int rtotal = sps.rtotal(shop_num);
		List<Img> imglist = is.list(shop_num);
		List<Star_point> reviewList = sps.reviewList(shop_num);
		List<Favor> favorList = fs.favorList(shop_num);
		List<Favor> colList = fs.colList(shop_num);
		Paging spg = new Paging(rtotal, currentPage);
		shop.setStart(spg.getStart()); // 시작
		shop.setEnd(spg.getEnd());// 끝
		model.addAttribute("reviewList", reviewList);
		model.addAttribute("imglist", imglist);
		model.addAttribute("shop", shop);
		model.addAttribute("favorList", favorList);
		model.addAttribute("colList", colList);

		System.out.println("찐막");

		return "shop/sdetail";
	}

	private String uploadFile(String originalName, byte[] fileData, String uploadPath) throws Exception {
		UUID uid = UUID.randomUUID();
		// requestPath = requestPath + "/resources/image";
		System.out.println("uploadPath->" + uploadPath);

		File fileDirectory = new File(uploadPath);
		if (!fileDirectory.exists()) {
			fileDirectory.mkdirs();
			System.out.println("업로드용 폴더 생성 : " + uploadPath);
		}

		String savedName = uid.toString() + "_" + originalName;
		// String path1 =
		// "C:\\spring\\springSrc39\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\sMybatis\\resources\\image";
		File target = new File(uploadPath, savedName);
		// File target = new File(requestPath, savedName);
		FileCopyUtils.copy(fileData, target);
		return savedName;
	}

	@RequestMapping(value = "s_updateForm")
	private String s_updateForm(int shop_num, Favor favor, Model model) {
		System.out.println("여기는 s업데이트폼");
		System.out.println("shop num ->" + shop_num);
		Shop shop = ss.sdetail(shop_num);
		List<Favor> favorlist = fs.list(favor);
		List<Img> imglist = is.list(shop_num);

		model.addAttribute("shop", shop);
		model.addAttribute("favorlist", favorlist);
		model.addAttribute("imglist", imglist);
		return "shop/s_updateForm";

	}

	@RequestMapping(value = "s_update", method = RequestMethod.POST)
	private String s_update(Shop shop, Model model, MultipartHttpServletRequest request, Favor favor, S_favor s_favor) {
		String uploadPath = request.getSession().getServletContext().getRealPath("/upload/");
		System.out.println("uploadForm POST Start");
		List<String> img_size = new ArrayList<String>();
		List<MultipartFile> fileList2 = request.getFiles("img1");
		System.out.println("이미지" + request.getFile("img1"));

		for (MultipartFile mf : fileList2) {
			logger.info("originalName: " + mf.getOriginalFilename());
			logger.info("size: " + mf.getSize());
			logger.info("contentType: " + mf.getContentType());
			String savedName = null;
			try {
				if (mf.getSize() >= 1) {
					savedName = uploadFile(mf.getOriginalFilename(), mf.getBytes(), uploadPath);
					logger.info("savedName: " + savedName);

					String new_img = "upload\\" + savedName;

					img_size.add(new_img);

				}

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			System.out.println("이미지 사이즈" + img_size);
		}
		int result2 = ss.s_update(shop);
		int s_num = shop.getShop_num();
		//List<Shop> shoplist = ss.list(shop);

		int sf_num = favor.getFavor_num();
		String[] sf_list = request.getParameterValues("favor_num");

		System.out.println("fileList2->" + fileList2.size());
		String file = request.getParameter("file");
		System.out.println("file->" + fileList2);

		if (img_size.size() != 0) {
			int imgdelete = is.imgdelete(s_num);
		}
		int delete = sfs.delete(s_num);
		int[] s_num10 = new int[sf_list.length];
		for (int i = 0; i < sf_list.length; i++) {
			s_num10[i] = s_num;
		}

		System.out.println("sf_list가선택안되면" + sf_list);
		HashMap<String, Object> hmap = new HashMap<String, Object>();
		for (int i = 0; i < sf_list.length; i++) {
			hmap.put("favor_num", sf_list[i]);
			hmap.put("shop_num", s_num10[i]);
			if (sf_list != null) {
				sfs.sfinsert(hmap);

			}

		}
		int[] s_num9 = new int[img_size.size()];
		for (int i = 0; i < img_size.size(); i++) {
			s_num9[i] = s_num;
		}
		HashMap<String, Object> imgmap = new HashMap<String, Object>();
		for (int i = 0; i < img_size.size(); i++) {
			imgmap.put("shop_num", s_num9[i]);
			imgmap.put("simg", img_size.get(i));

			is.fileuplod(imgmap);
		}
		// int sf_modify = sfs.sfmodify(s_num, sfs_list6,sf_list4);

		return "redirect:shoplist.do";

	}

	@RequestMapping(value = "s_deleteForm")
	public String s_deleteForm(int shop_num, Model model) {
		System.out.println("딜리트폼" + shop_num);
		sps.reviewdelete(shop_num);
		System.out.println("리뷰딜리트폼");
		sfs.sfavordelete(shop_num);
		System.out.println("에스빼버딜리트폼");
		is.allimgdelete(shop_num);
		System.out.println("이미지딜리트폼");
		ss.shopdelete(shop_num);
		System.out.println("샾딜리트폼");
		return "redirect:shoplist.do";
	}

	/*
	 * @RequestMapping(value = "imgupdate",method=RequestMethod.POST)
	 * 
	 * @ResponseBody public int imgupdate(int sh_num, Model model) {
	 * System.out.println("이미지 업데이트 수정 왔냐");
	 * 
	 * System.out.println("sh_num값"+sh_num); return is.imgdelete(sh_num);
	 * 
	 * }
	 */
	@RequestMapping(value = "reviewWrite", method = RequestMethod.POST)
	private String reviewWrite(int shop_num, Model model, Star_point star_point, Shop shop) {
		int reviewWrite = sps.reviewWrite(star_point);
		double s_pointSum = sps.s_pointSum(shop_num);
		double s_pointCount = sps.s_pointCount(shop_num);

		double shop_staravg = s_pointSum / s_pointCount;
		if (Double.isNaN(shop_staravg)) {
			shop_staravg = 0;
		}
		shop.setShop_staravg(shop_staravg);
		System.out.println("너입시발 ㄴ알 나와" + shop.getShop_staravg());
		double shop_staravg1 = ss.shop_staravg(shop);

		System.out.println("에스포인트 합계" + s_pointSum);

		model.addAttribute("reviewWrite", reviewWrite);
		model.addAttribute("s_pointSum", s_pointSum);
		model.addAttribute("s_pointCount", s_pointCount);

		return "redirect:sdetail.do?shop_num=" + shop_num;
	}

	@RequestMapping(value = "reviewModify", method = RequestMethod.POST)
	private String reviewModify(int shop_num, Model model, Star_point star_point, Shop shop) {
		int reviewModify = sps.reviewModify(star_point);
		double s_pointSum = sps.s_pointSum(shop_num);
		double s_pointCount = sps.s_pointCount(shop_num);
		System.out.println("별점 평균 식이 문제");
		double shop_staravg = s_pointSum / s_pointCount;
		if (Double.isNaN(shop_staravg)) {
			shop_staravg = 0;
		}
		shop.setShop_staravg(shop_staravg);
		System.out.println("별점 평균 함수가 문제");
		double shop_staravg1 = ss.shop_staravg(shop);
		model.addAttribute("reviewModify", reviewModify);
		model.addAttribute("s_pointSum", s_pointSum);
		model.addAttribute("s_pointCount", s_pointCount);
		model.addAttribute("shop_staravg1", shop_staravg1);
		return "redirect:sdetail.do?shop_num=" + shop_num;
	}

	@RequestMapping(value = "reviewDelete")
	private String reviewDelete(int shop_num, Model model, Star_point star_point, Shop shop, String member_id) {
		System.out.println("리뷰삭제 컨트롤러 왓니?");
		int reviewDelete = sps.reviewDelete(star_point);
		System.out.println("어디가 문제니6");
		double s_pointSum = sps.s_pointSum(shop_num);
		System.out.println("어디가 문제니5");
		double s_pointCount = sps.s_pointCount(shop_num);
		System.out.println("어디가 문제니4");
		double shop_staravg = s_pointSum / s_pointCount;
		if (Double.isNaN(shop_staravg)) {
			shop_staravg = 0;
		}
		System.out.println("어디가 문제니3");
		shop.setShop_staravg(shop_staravg);
		System.out.println("어디가 문제니");
		double shop_staravg1 = ss.shop_staravg(shop);
		System.out.println("어디가 문제니2");
		model.addAttribute("reviewDelete", reviewDelete);
		model.addAttribute("s_pointSum", s_pointSum);
		model.addAttribute("s_pointCount", s_pointCount);
		model.addAttribute("shop_staravg1", shop_staravg1);

		return "redirect:sdetail.do?shop_num=" + shop_num;
	}

}
