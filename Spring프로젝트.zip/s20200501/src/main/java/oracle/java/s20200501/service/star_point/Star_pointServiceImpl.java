package oracle.java.s20200501.service.star_point;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200501.dao.star_point.Star_pointDao;
import oracle.java.s20200501.model.Star_point;

@Service
public class Star_pointServiceImpl implements Star_pointService {
	@Autowired
	private Star_pointDao spd;

	@Override
	public List<Star_point> reviewList(int shop_num) {
		// TODO Auto-generated method stub
		return spd.reviewList(shop_num);
	}

	@Override
	public int rtotal(int shop_num) {
		// TODO Auto-generated method stub
		return spd.rtotal(shop_num);
	}

	@Override
	public int reviewWrite(Star_point star_point) {
		// TODO Auto-generated method stub
		return spd.reviewWrite(star_point);
	}

	@Override
	public int s_pointSum(int shop_num) {
		// TODO Auto-generated method stub
		return spd.s_pointSum(shop_num);
	}

	@Override
	public int s_pointCount(int shop_num) {
		// TODO Auto-generated method stub
		return spd.s_pointCount(shop_num);
	}

	@Override
	public int reviewdelete(int shop_num) {
		System.out.println("리뷰딜리트 서비스");
		return spd.review(shop_num);
		
	}
	@Override
	   public int reviewModify(Star_point star_point) {
	      // TODO Auto-generated method stub
	      return spd.reviewModify(star_point);
	   }

	   @Override
	   public int reviewDelete(Star_point star_point) {
	      // TODO Auto-generated method stub
	      return spd.reviewDelete(star_point);
	   }
}
