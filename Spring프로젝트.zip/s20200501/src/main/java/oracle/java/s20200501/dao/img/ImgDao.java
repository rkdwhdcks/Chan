package oracle.java.s20200501.dao.img;

import java.util.HashMap;
import java.util.List;

import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.Shop;

public interface ImgDao {

	

	

	int fileuplod(HashMap<String, Object> imgmap);

	

	List<Img> imglist(int shop_num);

	int imgdelete(int s_num);



	int allimgdelete(int shop_num);

	

	

}
