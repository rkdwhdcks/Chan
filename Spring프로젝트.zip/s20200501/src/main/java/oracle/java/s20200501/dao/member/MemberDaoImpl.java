package oracle.java.s20200501.dao.member;

import oracle.java.s20200501.model.Img;
import oracle.java.s20200501.model.M_favor;
import oracle.java.s20200501.model.Member;
import oracle.java.s20200501.model.MemberVO;
import oracle.java.s20200501.model.S_favor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	private SqlSession session;
	
	@Override
	public Member select(Member member) {
		Member member1 = null;
		System.out.println("MemberDaoImpl select...");
		System.out.println("MemberDaoImpl select member.getMember_id()->"+member.getMember_id());
		System.out.println("MemberDaoImpl select member.getMember_pw()->"+member.getMember_pw());
//		HashMap<String, Object> map = new HashMap<String, Object>();
//		map.put("member_id",member.getMember_id());
//		map.put("member_pw",member.getMember_pw());
		try {
			member1 = session.selectOne("MemberLogin", member);
			System.out.println("MemberDaoImpl select member1.getMember_id()->"+member1.getMember_id());
			System.out.println("MemberDaoImpl select member1.getMember_pw()->"+member1.getMember_pw());
			System.out.println("MemberDaoImpl select member1.getNickname()->"+member1.getNickname());
		} catch (Exception e) {
			System.out.println("MemberDaoImpl select e.getMessage()->"+e.getMessage());
		}
		
		
		return member1;
	}

	@Override
	public List<Member> list(Member member) {
		System.out.println("MemberDaoImpl list...");
		return session.selectList("listAll", member);
	}

//	@Override
//	public int insert(Member member) {
//		System.out.println("MemberDaoImpl insert...");
//		return session.insert("signUp", member);
//	}

	@Override
	public MemberVO insertMemberVO(MemberVO memberVO) {
		System.out.println("MemberDaoImpl insertMemberVO...");
		return session.selectOne("joinUp", memberVO);
	}

	@Override
	public String findid(Member member) {
		System.out.println("MemberDaoImpl findid...");
		return session.selectOne("findid", member);
	}

	@Override
	public String findPw(Member member) {
		System.out.println("MemberDaoImpl findPw...");
		return session.selectOne("findPw", member);
	}

	@Override
	public int pwUpdate(Member member1) {
		System.out.println("MemberDaoImpl pwUpdate...");
		return session.update("pwUpdate", member1);
	}

	@Override
	public int modifyUpdate(HashMap<String, Object> member) {
		System.out.println("MemberDaoImpl modifyUpdate...");
		return session.update("modifyUpdate", member);
	}

	@Override
	public Member joinDetail(String member_id) {
		System.out.println("MemberDaoImpl joinDetail...");
		return session.selectOne("joinDetail", member_id);
	}



}
