package oracle.java.s20200501.service.m_favor;

import java.util.HashMap;
import java.util.List;

import oracle.java.s20200501.model.M_favor;

public interface M_favorService {

	int mfinsert(HashMap<String, Object> hmap);

	List<M_favor> M_favorList(String member_id);



}
