package oracle.java.s20200501.model;

public class Star_point {
	private int shop_num;
	private String member_id;
	private int s_point;
	private String review;
	
	private int s_pointAvg;
	private String search;
	private String keyword;
	private String pageNum;
	private int start;
	
	
	
	public int getS_pointAvg() {
		return s_pointAvg;
	}
	public void setS_pointAvg(int s_pointAvg) {
		this.s_pointAvg = s_pointAvg;
	}
	public String getSearch() {
		return search;
	}
	public String getKeyword() {
		return keyword;
	}
	public String getPageNum() {
		return pageNum;
	}
	public int getStart() {
		return start;
	}
	public int getEnd() {
		return end;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public void setPageNum(String pageNum) {
		this.pageNum = pageNum;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	private int end;
	
	
	
	
	public int getShop_num() {
		return shop_num;
	}
	public String getMember_id() {
		return member_id;
	}
	
	public String getReview() {
		return review;
	}
	public void setShop_num(int shop_num) {
		this.shop_num = shop_num;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	
	public int getS_point() {
		return s_point;
	}
	public void setS_point(int s_point) {
		this.s_point = s_point;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
}