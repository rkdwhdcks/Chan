package oracle.java.s20200501.dao.s_favor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.java.s20200501.model.Favor;
import oracle.java.s20200501.model.S_favor;

public interface S_favorDao {

	/*int sfinsert(int s_num, String[] sf_list);*/

	int sdelete(int s_num);

	

	



	int sfinsert(HashMap<String, Object> hmap);







	int sfavordelete(int shop_num);

	

}
